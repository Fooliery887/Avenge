import pygame
import random
from spacesets import *
from sheet import *
from pyginum import *


spacejunk = 'spacejunk.png'
spacejunk2 = 'spacejunk2.png'
class live_stars(pygame.sprite.Sprite):
    def __init__(self):
        pygame.sprite.Sprite.__init__(self)
        
        self.star_size = random.randrange(1,4)
        self.glow = random.randrange(0,1)
        self.image = pygame.Surface((8,8),pygame.HWSURFACE|pygame.DOUBLEBUF)
        self.image.fill(black)
        self.image.set_colorkey(black)
        self.rect = self.image.get_rect()
        self.image1 = pygame.draw.circle(self.image, white, (3,3),self.star_size,self.glow)
        self.rect.x = random.randrange(-1,wth + 1)
        self.rect.y = random.randrange(-hgt,hgt)
        self.speed = random.randrange(1,4)
    def update(self):
        self.rect.y += self.speed
        if self.rect.y > hgt + 10:
            self.rect.y = -100
class live_objects(pygame.sprite.Sprite):
    def __init__(self,game):
        pygame.sprite.Sprite.__init__(self)
        self.game = game
        #self.sheet = Sheet(spacejunk)
        #self.sheet2 = Sheet(spacejunk2)
        #self.sheet3 = Sheet('pa.png')
        self.regen = random.randrange(-1,wth + 1)
        self.last_update = 0
        self.lll = 0
        self.size = random.choice([50, 100, 150, 250, 300, 350, 400, 450, 500])
        
        '''self.image = random.choice([self.sheet.get_image4(0,0,360,350),
                                                           self.sheet.get_image4(375,0,775,350),
                                                            self.sheet.get_image5(345,695,95,95),
                                                            self.sheet.get_image5(535,750,95,95),
                                                            self.sheet.get_image5(210,840,75,110),
                                    self.sheet.get_image3(400,400,175,175),
                                    self.sheet.get_image3(630,390,175,175),
                                    self.sheet2.get_image4(0,0,360,350),
                                    self.sheet2.get_image4(375,0,775,350)])'''
        self.image = random.choice(self.game.hdplanets)
        self.image = pygame.transform.scale(self.image, (self.size, self.size))
     
        self.image.set_colorkey(black)
        self.rect = self.image.get_rect()
       
        self.rect.x = random.randrange(-1,wth + 1)
        self.rect.y = random.randrange(-hgt,hgt)
        self.speed = random.randrange(2,3)


    def update(self):
        self.rect.y += self.speed
        if self.rect.y > hgt + 10:
            self.rect.y = -600
            self.regen = random.randrange(-1, wth + 1)
            self.rect.x = self.regen
            self.image = random.choice(self.game.hdplanets)
            self.size = random.choice([50, 100, 150, 250, 300, 350, 400, 450, 500])
            self.image = pygame.transform.scale(self.image,(self.size,self.size))



class live_planet_turn(pygame.sprite.Sprite):
    def __init__(self,game):
        pygame.sprite.Sprite.__init__(self)
        self.game = game
        self.sheet = Sheet(spacejunk)
        self.sheet2 = Sheet(spacejunk2)
        self.sheet3 = Sheet('planet_end.png')
        self.regen = random.randrange(-1,wth + 1)
        self.last_update = 0
        self.lll = 0
        self.image = self.sheet3.get_image3(0,0,220,220)
        self.image.set_colorkey(black)
        self.rect = self.image.get_rect()
        self.rect.x = 50
        self.rect.y = hgt -600
        self.load()
        self.changei = 0
        self.alive = True
        self.done = False
        self.grat = 1000
    def load(self):
        self.list = [self.sheet3.get_image3(0,0,220,220),
                     self.sheet3.get_image3(260,0,220,215)]
        self.list2 = [self.sheet3.get_image3(0,230,220,220),
                     self.sheet3.get_image3(261,240,220,220)]
        for i in self.list:
            i.set_colorkey(white)
        for i in self.list2:
            i.set_colorkey(white)

    def update(self):

        now = pygame.time.get_ticks()
        if now - self.last_update > self.grat:
            self.last_update = now
            if self.alive:
                self.lll = (self.lll + 1)% len(self.list)
                self.image = self.list[self.lll]
            if not self.alive and not self.done:
                self.grat = 100
                self.changei += 1
                self.lll = (self.lll + 1) % len(self.list2)
                self.image = self.list2[self.lll]
                if self.changei > 10:

                    self.done = True
            if self.done:
                self.changei += 1
                self.image = self.sheet3.get_image(535,40,455,370)
                self.image.set_colorkey(white)
            if self.changei > 12:
                self.game.draw_text(None, 'Nooooooo!!!!!', 60, black, wth // 2, hgt // 2)
                pygame.time.wait(200)
                self.game.wait_for_key()
                self.game.draw_text(None, 'This cant be!!', 60, black, wth // 2, (hgt // 2) + 50)
                pygame.time.wait(200)
                self.game.wait_for_key()
                self.kill()

class space_town(pygame.sprite.Sprite):
    def __init__(self,game):
        pygame.sprite.Sprite.__init__(self)
        self.game = game
        self.panrand = random.randrange(50,300)

        self.image = random.choice(self.game.planets)
        self.image.set_colorkey(white)
        self.image = pygame.transform.scale(self.image,(self.panrand,self.panrand))
        self.rect = self.image.get_rect()
        self.rect.x = random.randrange(-1, wth + 1)
        self.rect.y = random.randrange(-hgt, hgt)
        self.speed = random.randrange(2, 3)
        self.regen = random.randrange(-1, wth + 1)
        self.last_update = 0
        self.lll = 0


            
    def update(self):
        self.rect.y += self.speed
        if self.rect.y > hgt + 10:
            self.rect.y = -600
            self.rect.x = self.regen
        if self.rect.y >= hgt:
            self.regen = random.randrange(-1, wth + 1)
            self.image = random.choice(self.game.planets)


class Portal(pygame.sprite.Sprite):
    def __init__(self,game):
        pygame.sprite.Sprite.__init__(self)
        self.game = game

        self.load()
        self.last_update = 0
        self.last_update2 = 0
        self.image = self.game.sheetwww.get_image9(0,0,480,300)
        self.rect = self.image.get_rect()
        self.current_frame2 = 0
        self.rect.x = -85
        self.rect.y = -hgt
        self.current_frame = 0
        self.speedy = 5
        self.enterit = False
        self.game.level4done = False
        self.game.own_group = pygame.sprite.Group()
        self.game.own_group.add(self.game.p)

    def load(self):
        self.frames = [self.game.sheetwww.get_image9(0,0,480,300),
                       self.game.sheetwww.get_image9(480,0,480,300),
                       self.game.sheetwww.get_image9(960,0,480,300),
                       self.game.sheetwww.get_image9(1440,0,480,300)]
        for i in self.frames:
            i.set_colorkey(white)
            i.convert()
        self.frames2 = [self.game.sheetwww.get_image9(0, 0, 480, 300),
                       self.game.sheetwww.get_image9(480, 0, 480, 300),
                       self.game.sheetwww.get_image9(960, 0, 480, 300),
                       self.game.sheetwww.get_image9(1440, 0, 480, 300)]
        for i in self.frames2:
            i.set_colorkey(white)
            i.convert()

    def ani(self):
        self.hits = pygame.sprite.spritecollide(self, self.game.own_group , False)
        if not self.hits:
            now = pygame.time.get_ticks()
            if now - self.last_update > 500:
                self.last_update = now
                self.current_frame = (self.current_frame + 1) % len(self.frames)
                self.image = self.frames[self.current_frame]
        else:
            print('4 hits')
            now = pygame.time.get_ticks()
            if now - self.last_update2 > 250:
                self.last_update2 = now
                if self.enterit == True:
                    self.current_frame2 = (self.current_frame2 + 1) % len(self.frames2)
                    self.image = self.frames2[self.current_frame2]
        if self.game.current_time == 3000:
            self.enterit = True
            self.game.draw_text(None,'NOWS YOUR CHANCE!!!!',40,black,wth // 2, 25)
            pygame.time.wait(200)
            self.game.wait_for_key()
            self.game.draw_text(None, 'GO THREW THE PORTAL!!!!', 40, black, wth // 2, 60)
            pygame.time.wait(200)
            self.game.wait_for_key()
        if self.enterit and self.hits:
            self.game.level4_done = True


    def update(self):
        self.ani()
        self.rect.y += self.speedy
        if self.rect.y == -125:
            self.speedy = 0



