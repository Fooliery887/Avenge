import pygame
import random
from spacesets import *
from sheet import *




class Bullet(pygame.sprite.Sprite):
    def __init__(self, x, y):
        pygame.sprite.Sprite.__init__(self)
        self.clock = pygame.time.Clock()
        self.image = pygame.image.load('b1.png').convert()
        self.image.set_colorkey(black)
        self.rect = self.image.get_rect()
        self.rect.bottom = y
        self.rect.centerx = x
        self.speedy = -10
        self.current_frame = 0
        self.last_update = 0
        self.load()

    def update(self):
        self.clock.tick(fps)
        self.ani()
        self.rect.y += self.speedy
        if self.rect.bottom < 0:
            self.kill()
        self.mask = pygame.mask.from_surface(self.image)

    def load(self):
        self.bb = [pygame.image.load('b1.png'),
                   pygame.image.load('b2.png')]
        for i in self.bb:
            i.convert()
            i.set_colorkey(black)

    def ani(self):
        now = pygame.time.get_ticks()
        no = pygame.time.get_ticks()
        if now - self.last_update > 100:
            self.last_update = now
            self.current_frame = (self.current_frame + 1) % len(self.bb)
            self.image = self.bb[self.current_frame]


class Bulletu2(pygame.sprite.Sprite):
    def __init__(self, x, y):
        pygame.sprite.Sprite.__init__(self)
        self.clock = pygame.time.Clock()
        self.image = pygame.image.load('b1.png').convert()
        self.image.set_colorkey(white)
        self.rect = self.image.get_rect()
        self.rect.bottom = y
        self.rect.centerx = x
        self.speedy = -10
        self.current_frame = 0
        self.last_update = 0
        self.speedx = random.randrange(-2, 2)
        self.load()

    def update(self):
        self.clock.tick(fps)
        self.ani()
        self.rect.y += self.speedy
        self.rect.x += self.speedx
        if self.rect.bottom < 0:
            self.kill()
        self.mask = pygame.mask.from_surface(self.image)

    def load(self):
        self.bb = [pygame.image.load('b1.png'),
                   pygame.image.load('b2.png')]
        for i in self.bb:
            i.set_colorkey(white)
            i.convert()

    def ani(self):
        now = pygame.time.get_ticks()
        no = pygame.time.get_ticks()
        if now - self.last_update > 100:
            self.last_update = now
            self.current_frame = (self.current_frame + 1) % len(self.bb)
            self.image = self.bb[self.current_frame]


class Bulletu1(pygame.sprite.Sprite):
    def __init__(self, x, y):
        pygame.sprite.Sprite.__init__(self)
        self.clock = pygame.time.Clock()
        self.sheet = Sheet('beams.png')
        self.image = self.sheet.get_image(34, 0, 20, 20).convert()
        self.image.set_colorkey(white)
        self.rect = self.image.get_rect()
        self.rect.bottom = y
        self.rect.centerx = x
        self.speedy = -10
        self.current_frame = 0
        self.last_update = 0
        self.load()

    def update(self):
        self.clock.tick(fps)
        self.ani()
        self.rect.y += self.speedy
        if self.rect.bottom < 0:
            self.kill()
        self.mask = pygame.mask.from_surface(self.image)

    def load(self):
        self.bb = [self.sheet.get_image(36, 0, 22, 20),
                   self.sheet.get_image(36, 26, 22, 30),
                   self.sheet.get_image(36, 56, 22, 45),
                   self.sheet.get_image(36, 56, 22, 45)]
        for i in self.bb:
            i.set_colorkey(white)
            i.convert()

    def ani(self):
        now = pygame.time.get_ticks()
        no = pygame.time.get_ticks()
        if now - self.last_update > 200:
            self.last_update = now
            self.current_frame = (self.current_frame + 1) % len(self.bb)
            self.image = self.bb[self.current_frame]
            if self.current_frame >= 4:
                self.current_frame = 4


class Bullet2_1(pygame.sprite.Sprite):
    def __init__(self, x, y,game):
        pygame.sprite.Sprite.__init__(self)
        self.game = game
        self.clock = pygame.time.Clock()

        self.image = self.game.sheetbub.get_image(11, 160, 4, 4).convert()
        self.image.set_colorkey(white)
        self.rect = self.image.get_rect()
        self.rect.bottom = y
        self.rect.centerx = x
        self.speedy = -10
        self.speedx = 0
        self.current_frame = 0
        self.last_update = 0

        self.wob = 0
        self.right = True

    def update(self):
        self.clock.tick(fps)
        self.wobble()
        self.ani()
        self.rect.y += self.speedy
        self.rect.x += self.speedx
        if self.rect.bottom < 0:
            self.kill()
        self.mask = pygame.mask.from_surface(self.image)


    def ani(self):
        if self.current_frame == 14:
            self.current_frame = 14
        now = pygame.time.get_ticks()
        if now - self.last_update > 100:
            self.last_update = now
            self.current_frame = (self.current_frame + 1) % len(self.game.bubble)
            self.image = self.game.bubble[self.current_frame]
            self.image.convert()
            self.image.set_colorkey(black)

    def wobble(self):
        noww = pygame.time.get_ticks()
        if noww - self.wob > 100:
            self.wob = noww
            if self.right == True:
                self.right = False
            elif self.right == False:
                self.right = True
        if self.right == True:
            self.speedx = 3
        else:
            self.speedx = -3


class Bullet2(pygame.sprite.Sprite):
    def __init__(self, x, y):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.image.load('gb.png')
        self.image.set_colorkey((0, 0, 0))
        self.image = pygame.transform.flip(self.image, True, True)
        self.rect = self.image.get_rect()
        self.rect.bottom = y
        self.rect.centerx = x
        self.speedy = 10

    def update(self):
        self.rect.y += self.speedy
        if self.rect.bottom > hgt:
            self.kill()
        self.mask = pygame.mask.from_surface(self.image)


class Bullet3(pygame.sprite.Sprite):
    def __init__(self, x, y):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.image.load('bullet3.png')
        self.image.set_colorkey((255, 255, 255))
        self.rect = self.image.get_rect()
        self.rect.bottom = y
        self.rect.centerx = x
        self.speedy = 7

    def update(self):
        self.rect.y += self.speedy
        if self.rect.bottom > hgt:
            self.kill()
        self.mask = pygame.mask.from_surface(self.image)


class Bossbullet(pygame.sprite.Sprite):
    def __init__(self, x, y):
        pygame.sprite.Sprite.__init__(self)

        self.sheet = Sheet('w_bullet.png')
        self.image = self.sheet.get_image8(0, 0, 41, 40).convert()
        self.image.set_colorkey((0, 0, 0))
        self.rect = self.image.get_rect()
        self.rect.midbottom = y
        self.rect.centerx = x
        self.speedy = 10
        self.load()
        self.current_frame = 0
        self.last_update = 0
        self.speedx = 0

    def load(self):
        self.ani = [self.sheet.get_image8(0, 0, 41, 40),
                    self.sheet.get_image8(54, 10, 35, 28),
                    self.sheet.get_image8(100, 10, 30, 25)]
        for i in self.ani:
            i.convert()
            i.set_colorkey(black)

    def update(self):
        self.rect.y += self.speedy
        self.rect.x += self.speedx
        self.animate()

        if self.rect.bottom > hgt:
            self.kill()
        self.mask = pygame.mask.from_surface(self.image)

    def superbullet(self):
        if self.g.p.rect.right < self.g.b.left and self.g.p.rect.right > self.g.b.left - 50:
            self.speedy = -1

    def animate(self):
        now = pygame.time.get_ticks()
        if now - self.last_update > 250:
            self.current_frame = (self.current_frame + 1) % len(self.ani)
            self.image = self.ani[self.current_frame]
            self.image.set_colorkey(black)
            self.image = pygame.transform.flip(self.image,False,True)

class Bossbulletb(pygame.sprite.Sprite):
    def __init__(self, x, y):
        pygame.sprite.Sprite.__init__(self)

        self.sheet = Sheet('w_bullet.png')
        self.image = self.sheet.get_image8(0, 0, 41, 40).convert()
        self.image.set_colorkey(white)
        self.rect = self.image.get_rect()
        self.rect.midbottom = y
        self.rect.centerx = x
        self.speedy = 10
        self.load()
        self.current_frame = 0
        self.last_update = 0
        self.speedx = 0

    def load(self):
        self.ani = [self.sheet.get_image8(0, 0, 41, 40),
                    self.sheet.get_image8(54, 10, 35, 28),
                    self.sheet.get_image8(100, 10, 30, 25)]
        for i in self.ani:
            i.convert()
            self.image.set_colorkey(black)



    def update(self):
        self.rect.y += self.speedy
        self.rect.x += self.speedx
        self.animate()

        if self.rect.bottom > hgt:
            self.kill()
        self.mask = pygame.mask.from_surface(self.image)


    def animate(self):
        now = pygame.time.get_ticks()
        if now - self.last_update > 250:
            self.current_frame = (self.current_frame + 1) % len(self.ani)
            self.image = self.ani[self.current_frame]
            self.image = pygame.transform.flip(self.image, False, True)
            self.image.convert()
            self.image.set_colorkey(black)
class Bossbullet_right(pygame.sprite.Sprite):
    def __init__(self, x, y):
        pygame.sprite.Sprite.__init__(self)

        self.sheet = Sheet('w_bullet.png')
        self.image = self.sheet.get_image8(0, 0, 41, 40).convert()
        self.image.set_colorkey(black)
        self.rect = self.image.get_rect()
        self.rect.midbottom = y
        self.rect.centerx = x
        self.speedy = 10
        self.load()
        self.current_frame = 0
        self.last_update = 0
        self.speedx = 2

    def load(self):
        self.ani = [self.sheet.get_image8(0, 0, 41, 40),
                    self.sheet.get_image8(54, 10, 35, 28),
                    self.sheet.get_image8(100, 10, 30, 25)]
        for i in self.ani:
            i.convert()
            i.set_colorkey(black)

    def update(self):
        self.rect.y += self.speedy
        self.rect.x += self.speedx
        self.animate()

        if self.rect.bottom > hgt:
            self.kill()
        self.mask = pygame.mask.from_surface(self.image)

    def superbullet(self):
        if self.g.p.rect.right < self.g.b.left and self.g.p.rect.right > self.g.b.left - 50:
            self.speedy = -1

    def animate(self):
        now = pygame.time.get_ticks()
        if now - self.last_update > 250:
            self.current_frame = (self.current_frame + 1) % len(self.ani)
            self.image = self.ani[self.current_frame]
            self.image = pygame.transform.flip(self.image, False, True)
            self.image.convert()
            self.image.set_colorkey(black)


class Bossbullet_left(pygame.sprite.Sprite):
    def __init__(self, x, y):
        pygame.sprite.Sprite.__init__(self)

        self.sheet = Sheet('w_bullet.png')
        self.image = self.sheet.get_image8(0, 0, 41, 40).convert()
        self.image.set_colorkey((0, 0, 0))
        self.rect = self.image.get_rect()
        self.rect.midbottom = y
        self.rect.centerx = x
        self.speedy = 10
        self.load()
        self.current_frame = 0
        self.last_update = 0
        self.speedx = -2

    def load(self):
        self.ani = [self.sheet.get_image8(0, 0, 41, 40),
                    self.sheet.get_image8(54, 10, 35, 28),
                    self.sheet.get_image8(100, 10, 30, 25)]
        for i in self.ani:
            i.convert()
            i.set_colorkey(black)

    def update(self):
        self.rect.y += self.speedy
        self.rect.x += self.speedx
        self.animate()

        if self.rect.bottom > hgt:
            self.kill()
        self.mask = pygame.mask.from_surface(self.image)

    def superbullet(self):
        if self.g.p.rect.right < self.g.b.left and self.g.p.rect.right > self.g.b.left - 50:
            self.speedy = -1

    def animate(self):
        now = pygame.time.get_ticks()
        if now - self.last_update > 250:
            self.current_frame = (self.current_frame + 1) % len(self.ani)
            self.image = self.ani[self.current_frame]


class Bossbullet_down(pygame.sprite.Sprite):
    def __init__(self, x, y):
        pygame.sprite.Sprite.__init__(self)

        self.sheet = Sheet('w_bullet.png')
        self.image = self.sheet.get_image8(0, 0, 41, 40).convert()
        self.image.set_colorkey((0, 0, 0))
        self.rect = self.image.get_rect()
        self.rect.midbottom = y
        self.rect.centerx = x
        self.speedy = 10
        self.load()
        self.current_frame = 0
        self.last_update = 0
        self.speedx = 0

    def load(self):
        self.ani = [self.sheet.get_image8(0, 0, 41, 40),
                    self.sheet.get_image8(54, 10, 35, 28),
                    self.sheet.get_image8(100, 10, 30, 25)]
        for i in self.ani:
            i.convert()
            i.set_colorkey(black)

    def update(self):
        self.rect.y += self.speedy
        self.rect.x += self.speedx
        self.animate()

        if self.rect.bottom > hgt:
            self.kill()
        self.mask = pygame.mask.from_surface(self.image)

    def superbullet(self):
        if self.g.p.rect.right < self.g.b.left and self.g.p.rect.right > self.g.b.left - 50:
            self.speedy = -1

    def animate(self):
        now = pygame.time.get_ticks()
        if now - self.last_update > 250:
            self.current_frame = (self.current_frame + 1) % len(self.ani)
            self.image = self.ani[self.current_frame]
            self.image.convert()
            self.image.set_colorkey(black)
            self.image = pygame.transform.flip(self.image,False,True)

class sider(pygame.sprite.Sprite):
    def __init__(self,game,x,y):
        pygame.sprite.Sprite.__init__(self)
        self.game = game
        self.image = pygame.image.load(SIDER1)
        self.image = pygame.transform.scale(self.image, (50, 50))
        self.rect = self.image.get_rect()
        self.rect.midbottom = y
        self.rect.centerx = x
        self.current_frame = 0
        self.last_update = 0
        self.alive = True

        self.speedx = 8
        self.speedy = 4

    def animate(self):
        now = pygame.time.get_ticks()
        if now - self.last_update > 100:
            self.last_update = now

            self.current_frame = (self.current_frame + 1) % len(self.game.siders)
            self.image = self.game.siders[self.current_frame]
            self.image = pygame.transform.scale(self.image, (50, 50))

    def update(self):
        self.animate()
        self.rect.x += self.speedx
        self.rect.y += self.speedy
        self.mask = pygame.mask.from_surface(self.image)
        if self.rect.x > wth:
            self.rect.x = -50
        if self.rect.y > hgt + 10:
            self.kill()

class lighting(pygame.sprite.Sprite):
    def __init__(self,p,x,y,game):
        pygame.sprite.Sprite.__init__(self)
        self.game = game
        self.p = p
        self.image = random.choice(self.game.Lightbullet)
        self.image = pygame.transform.scale(self.image,(50, 50))

        self.rect = self.image.get_rect()
        self.rect.bottom = y
        self.rect.centerx = x
        self.current_frame = 0
        self.last_update = 0
        self.alive = True

        self.speedx = 0
        self.speedy = -10



    def animate(self):
        now = pygame.time.get_ticks()
        if now - self.last_update > 100:
            self.last_update = now

            self.current_frame = (self.current_frame + 1) % len(self.game.Lightbullet)
            self.image = self.game.Lightbullet[self.current_frame]
            self.image = pygame.transform.scale(self.image,(50,50))
            self.image = pygame.transform.flip(self.image,True,True)


    def update(self):
        self. animate()
        self.mask = pygame.mask.from_surface(self.image)
        self.rect.x += self.speedx
        self.rect.y += self.speedy
        if self.rect.y < -10:
            self.kill()




