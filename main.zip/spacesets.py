import pygame
import random


wth = 800
hgt = 700
fps = 60

title = 'my game'




black = (0,0,0)
white = (255,255,255)
red = (255,0,0)
green = (0,255,0)
blue = (0,0,255)
yellow = (255,255,0)
lightblue = (0,155,155)
grey = (90,90,90)
blurple = (90,90,255)
pink = (255,90,255)
hotpink = (255,50,90)
lime = (0,255,90)
peach = (255,255,90)
pumpkin = (255,190,40)
junglegreen = (100,200,40)
purple = (255,0,255)

mc2 = 'e.png'
spritesheet = 'explode.png'
spacejunk = 'spacejunk.png'
ass = 'ass.png'

SHIP1_FRONT = 'ship_1.png'
SHIP1_LEFT = 'ship_2.png'
SHIP1_RIGHT = 'ship_3.png'

SHIP2_FRONT = 'redfighter0005.png'
SHIP2_RIGHT = 'redfighter0009.png'
SHIP2_LEFT = 'redfighter0001.png'

HELPER1 = 'cool_boss2.png'

BOSS1 = 'boss.png'

BOSSUFO = 'UFO.png'

BOSSDOVE = 'dove.png'

BOSSG1 = 'bads\\greenship1.png'

BOSSG2 = 'bads\\greenship2.png'

BOSSG3 = 'bads\\greenship3.png'

BOSSG4 = 'bads\\greenship4.png'

MOB1 = 'img2/items/spaceship.png'
MOB2 = 'img2/Enemies/mob2.png'
MOB3 = 'img2/Enemies/red_enemy_ship.png'
MOB4 = 'img2/Enemies/red_enemy_ship.png'
ALEX1 = 'alex001.png'
POWERUP1 = 'star-plat.png'

POWERUP2 = 'shield2\\00.png'

SIDER1 = 'sider\\00.png'
SIDER2 = 'sider\\01.png'
SIDER3 = 'sider\\02.png'
SIDER4 = 'sider\\03.png'
SIDER5 = 'sider\\04.png'
SIDER6 = 'sider\\05.png'

LIGHTING1 = 'lightning\\00.png'
LIGHTING2 = 'lightning\\01.png'
LIGHTING3 = 'lightning\\02.png'
LIGHTING4 = 'lightning\\03.png'
LIGHTING5 = 'lightning\\04.png'
LIGHTING6 = 'lightning\\05.png'
LIGHTING7 = 'lightning\\06.png'
LIGHTING8 = 'lightning\\07.png'
LIGHTING9 = 'lightning\\08.png'
LIGHTING10 = 'lightning\\09.png'
LIGHTING11 = 'lightning\\10.png'
LIGHTING12 = 'lightning\\11.png'
LIGHTING13 = 'lightning\\12.png'
LIGHTING14 = 'lightning\\13.png'
LIGHTING15 = 'lightning\\14.png'
LIGHTING16 = 'lightning\\15.png'
LIGHTING17 = 'lightning\\16.png'
LIGHTING17 = 'lightning\\17.png'

BAXONE = 'bg5.jpg'
BAXTWO = 'space001.png'
BAXTHREE = 'space002.png'
BAXFOUR = 'space003.png'
BAXFIVE = 'space004.png'

