from cx_Freeze import setup, Executable

setup(
	name = "spaceshooterREMASTEDgame",
	version = "0.1",
	description  = "classic space shooter",
	executables = [Executable(spaceshooterREMASTEDgame.py)])
