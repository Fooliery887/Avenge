import pygame
import random
from spacesets import *
from sheet import *




class Coin(pygame.sprite.Sprite):
    def __init__(self):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.image.load('img2/Items\coinGold.png').convert()
        self.image.set_colorkey((0, 0, 0))

        self.rect = self.image.get_rect()
        self.rect.x = random.randrange(50, 350)
        self.rect.y = random.randrange(-100, -40)
        self.speedy = random.randrange(4, 5)
        self.speedx = random.randrange(-1, 1)

    def update(self):
        self.rect.x += self.speedx
        self.rect.y += self.speedy
        if self.rect.top > height + 10:
            self.kill()
        self.mask = pygame.mask.from_surface(self.image)


class Powerup(pygame.sprite.Sprite):
    def __init__(self):
        pygame.sprite.Sprite.__init__(self)
        self.sheet = Sheet('gem.png')

        self.image = self.sheet.get_image(0, 0, 15, 15).convert()
        self.image.set_colorkey(black)

        self.rect = self.image.get_rect()
        self.rect.x = random.randrange(0, wth)
        self.rect.y = random.randrange(-hgt, -10)
        self.speedy = 2
        self.speedx = 0
        self.load()
        self.last_update = 0
        self.current_frame = 0

    def load(self):
        self.blows = [self.sheet.get_image(0, 0, 15, 15),
                      self.sheet.get_image(15, 0, 15, 15),
                      self.sheet.get_image(30, 0, 15, 15),
                      self.sheet.get_image(45, 0, 15, 15),
                      self.sheet.get_image(60, 0, 15, 15)]
        for i in self.blows:
            i.set_colorkey(black)
            i.convert()

    def ani(self):
        now = pygame.time.get_ticks()
        if now - self.last_update > 100:
            self.last_update = now
            self.current_frame = (self.current_frame + 1) % len(self.blows)
            self.image = self.blows[self.current_frame]

    def update(self):
        self.ani()
        self.rect.x += self.speedx
        self.rect.y += self.speedy
        if self.rect.top > hgt + 10:
            self.kill()
        self.mask = pygame.mask.from_surface(self.image)





class playsound:
    def __init__(self, game):
        self.game = game
        if self.game.wepon == 0:
            pygame.mixer.music.load('sounds\\shoot.mp3')
            pygame.mixer.music.play()
        if self.game.wepon == 1:
            pygame.mixer.music.load('sounds\\foom_0.wav')
            pygame.mixer.music.play()
        if self.game.wepon == 2:
            pygame.mixer.music.load('sounds\\sfx_laser1.ogg')
            pygame.mixer.music.play()
        if self.game.wepon == 3:
            pygame.mixer.music.load('sounds\\8bit_bomb_explosion.wav')
            pygame.mixer.music.play()
    def death(self):
        pygame.mixer.music.load('sounds\\8bit_bomb_explosion.wav')
        pygame.mixer.music.play()
    def button(self):
        pygame.mixer.music.load('sounds\\sounds\\Blip_Select.wav')
        pygame.mixer.music.play()
    def death2(self):
        pygame.mixer.music.load('sounds\\Randomize3.wav')
        pygame.mixer.music.play()
    def exept(self):
        pygame.mixer.music.load('sounds\\Pickup_coin.wav')
        pygame.mixer.music.play()
    def lilboom(self):
        pygame.mixer.music.load('sounds\\Explosion12.wav')
        pygame.mixer.music.play()
    def switchwep(self):
        pygame.mixer.music.load('sounds\\Powerup2.wav')
        pygame.mixer.music.play()
    def openmart(self):
        pygame.mixer.music.load('sounds\\menu1A.wav')
        pygame.mixer.music.play()
    def closemart(self):
        pygame.mixer.music.load('sounds\\menu1B.wav')
        pygame.mixer.music.play()









class tex(pygame.sprite.Sprite):
    def __init__(self, xx, yy, game):
        pygame.sprite.Sprite.__init__(self)
        self.game = game
        self.sheet = Sheet('beams.png')
        self.image = pygame.image.load('gametext.png')
        self.image.fill(black)
        self.image = pygame.image.load('gametext.png')
        self.image.set_colorkey(black)
        self.rect = self.image.get_rect()
        self.rect.x = xx
        self.rect.y = yy

    def draw_text(self, text, y):
        font = pygame.font.Font(None, 20)

        text_surface = font.render(text, True, grey)
        text_surface.set_colorkey(black)
        text_rect = text_surface.get_rect()
        text_rect.midtop = (100, y)
        self.image.blit(text_surface, text_rect)

    def draw_text2(self, text, size, x, y):
        font = pygame.font.Font(None, size)

        text_surface = font.render(text, True, grey)
        text_surface.set_colorkey(black)
        text_rect = text_surface.get_rect()
        text_rect.midtop = (x, y)
        self.image.blit(text_surface, text_rect)

    def draw_text_wit_clr(self, text, y, c):
        font = pygame.font.Font(None, 20)

        text_surface = font.render(text, True, c)
        text_surface.set_colorkey(black)
        text_rect = text_surface.get_rect()
        text_rect.midtop = (25, y)
        self.image.blit(text_surface, text_rect)

    def rank_stats(self):
        if self.game.rank == 0:
            self.gun_upgrade_one = pygame.image.load('rank0.png')
            self.gun_upgrade_one.set_colorkey(white)
            self.gun_upgrade_one = pygame.transform.scale(self.gun_upgrade_one, (190, 190))
            self.image.blit(self.gun_upgrade_one, (10, 10))

        if self.game.rank == 1:
            self.gun_upgrade_one = pygame.image.load('rank1.png')
            self.gun_upgrade_one.set_colorkey(white)
            self.gun_upgrade_one = pygame.transform.scale(self.gun_upgrade_one, (190, 190))
            self.image.blit(self.gun_upgrade_one, (10, 10))
        if self.game.rank == 2:
            self.gun_upgrade_one = pygame.image.load('rank2.png')
            self.gun_upgrade_one.set_colorkey(white)
            self.gun_upgrade_one = pygame.transform.scale(self.gun_upgrade_one, (190, 190))
            self.image.blit(self.gun_upgrade_one, (10, 10))
        if self.game.rank == 3:
            self.gun_upgrade_one = pygame.image.load('rank3.png')
            self.gun_upgrade_one.set_colorkey(white)
            self.gun_upgrade_one = pygame.transform.scale(self.gun_upgrade_one, (190, 190))
            self.image.blit(self.gun_upgrade_one, (10, 10))

    def weps(self):
        if self.game.wepon >= 0:
            self.weapon_list1 = pygame.image.load(LIGHTING1)
            self.weapon_list1.set_colorkey(white)
            self.weapon_list1 = pygame.transform.scale(self.weapon_list1, (25, 50))
            self.image.blit(self.weapon_list1, (50, 50))

        if self.game.wepon >= 1:
            self.weapon_list2 = self.sheet.get_image(36, 26, 22, 30)
            self.weapon_list2.set_colorkey(white)
            self.weapon_list2 = pygame.transform.scale(self.weapon_list2, (50, 50))
            self.image.blit(self.weapon_list2, (85, 50))


        if self.game.wepon >= 2:
            self.weapon_list3 = pygame.image.load('b1.png')
            self.weapon_list3.set_colorkey(white)
            self.weapon_list3 = pygame.transform.scale(self.weapon_list3, (25, 50))
            self.image.blit(self.weapon_list3, (145, 50))
            self.image.blit(self.weapon_list3, (155, 55))
            self.image.blit(self.weapon_list3, (165, 60))

        if self.game.wepon >= 3:
            self.sheet2 = Sheet('zaps.png')
            self.weapon_list4 = self.sheet2.get_image(127, 151, 15, 15)
            self.weapon_list4.set_colorkey(white)
            self.weapon_list4 = pygame.transform.scale(self.weapon_list4, (25, 50))
            self.image.blit(self.weapon_list4, (50, 100))

        if self.game.ship >= 2:
            self.weapon_list5 = self.game.red1
            self.weapon_list5.set_colorkey(white)
            self.weapon_list5 = pygame.transform.scale(self.weapon_list5, (25, 50))
            self.image.blit(self.weapon_list5, (100, 100))


    def new_screen(self):
        self.image.fill(black)
        self.image = pygame.image.load('gametext.png')
        self.image.set_colorkey(black)