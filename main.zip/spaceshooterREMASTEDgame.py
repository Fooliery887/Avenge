import pygame
import random
from spacesets import *
from spacesprites import *
from live_backround import *
from objects import *
from bullets import *
from sheet import *

'''mine is the bestest'''
class Game:

    def __init__(self):
        
        self.boss3_death_count = 0
        self.boss3_kills = pygame.sprite.Group()
        self.shielded = False
        pygame.init()
        pygame.mixer.init()
        self.fullscreen = pygame.FULLSCREEN
        self.screen = pygame.display.set_mode((wth,hgt),pygame.DOUBLEBUF|pygame.HWSURFACE|self.fullscreen)
        pygame.display.set_caption(title)
        self.clock = pygame.time.Clock()
        self.running = True
        self.pause_tx_size = 1
        self.play_credits = 600
        self.start_planet = pygame.image.load('start_planet.png').convert()
        self.start_planet.set_colorkey(black)
        self.sceen_start = pygame.image.load('sceen_start.png').convert()
        self.start_sceen_tx = hgt
        self.start_sceen_tx1 = hgt + 200
        self.sound1 = 'music\\start.ogg'
        self.purplebax = pygame.image.load('bg5.jpg')
        self.purplebax = pygame.transform.scale(self.purplebax,(wth,hgt))

        self.next_wave = 0

        self.boss2_hp = 20

        self.level = 3

        self.survival_mode_unlocked = False
        self.coin_count = 0
        self.rank = 4
        self.wepon = 3
        self.damage = 0
        self.score = 0
        self.played = False
        self.times_died = 0
        self.ship = 2
        self.did_buy_wep1 = True
        self.did_buy_wep2 = True
        self.did_buy_wep3 = True
        self.did_buy_wep4 = True
        self.did_buy_ship1 = True
        self.atex = pygame.font.Font('aaa.ttf',40)
        self.btex = pygame.font.Font('n.ttf',30)
        self.last_min_tuches()



        
        
        
        
    def new(self):
        self.SHEILD = [pygame.image.load('bulls\\00.png'),
                    pygame.image.load('bulls\\01.png'),
                    pygame.image.load('bulls\\02.png'),
                    pygame.image.load('bulls\\03.png'),
                    pygame.image.load('bulls\\04.png'),
                    pygame.image.load('bulls\\05.png'),
                    pygame.image.load('bulls\\06.png'),
                    pygame.image.load('bulls\\07.png'),
                    pygame.image.load('bulls\\08.png'),
                    pygame.image.load('bulls\\09.png'),
                    pygame.image.load('bulls\\10.png'),
                    pygame.image.load('bulls\\11.png')]
        if self.survival_mode_unlocked:
            self.pick_your_level()

        if self.level == 1:
            pygame.mixer.Channel(0).play(pygame.mixer.Sound('music\\start.ogg'))
        if self.level == 2:
            pygame.mixer.Channel(0).play(pygame.mixer.Sound('music\\TheLoomingBattle_0.OGG'))
            self.hdplanets = [pygame.image.load('hd\\p1.png'),
                                    pygame.image.load('hd\\p2.png'),
                                    pygame.image.load('hd\\p3.png'),
                                    pygame.image.load('hd\\p4.png'),
                                    pygame.image.load('hd\\p5.png')]
        if self.level == 3:
            pygame.mixer.Channel(0).play(pygame.mixer.Sound('music\\Ove Melaa - Dark Blue_0.ogg'))
            self.planets = [pygame.image.load('Planet0.png'),
                           pygame.image.load('Planet1.png'),
                           pygame.image.load('Planet2.png'),
                           pygame.image.load('Planet3.png'),
                           pygame.image.load('Planet4.png'),
                           pygame.image.load('Planet5.png'),
                           pygame.image.load('Planet6.png'),
                           pygame.image.load('Planet8.png'),
                           pygame.image.load('Planet9.png')]
            self.boss3_spawn = False
        if self.level == 4:
            pygame.mixer.Channel(0).play(pygame.mixer.Sound('music\\InnerCore_High.ogg'))
        if self.level == 5:
            self.credits2()
            self.credits()
            pygame.mixer.Channel(0).play(pygame.mixer.Sound('music\\start.ogg'))
            self.survival_mode_unlocked = True
            pygame.time.wait(100)
        self.b = Boss2(self)
        self.timer = 0
        self.up = 0
        self.current_time = 0
        self.update_it = 0
        self.u = 0
        self.ff = 0
        if self.played and not self.survival_mode_unlocked:
            self.level = 1
            self.coin_count = 0
            self.rank = 0
            self.wepon = 0
            self.damage = 0
            self.score = 0
            self.times_died += 1
        
        self.boss1 = Boss3(self)
        self.bullets = pygame.sprite.Group()
        self.bullets2 = pygame.sprite.Group()
        self.mobs = pygame.sprite.Group()
        self.gets = pygame.sprite.Group()
        self.gam = pygame.sprite.Group()
        self.player = pygame.sprite.Group()
        self.keep_coming = pygame.sprite.Group()
        self.frontr = pygame.sprite.LayeredUpdates()
        self.siderbulls = pygame.sprite.Group()
        self.backround_layer()
        if self.ship == 1:
            self.p = Player(self)
            self.gam.add(self.p)
            self.player.add(self.p)
            self.frontr.add(self.p)
        if self.ship == 2:
            self.p = Player2(self)
            self.gam.add(self.p)
            self.player.add(self.p)
            self.frontr.add(self.p)
        self.mobs = pygame.sprite.Group()
        self.played = False
        self.play_check = True
        self.helper_alive = False
        self.help = helper(self)
        self.rand_time = random.choice([500,1000,1500,2000,2500,2800])#,1000,1500,2000,2500,2800
        self.rand_time2 = random.choice([50,1100,1550,2100,2500,2800])  # ,1100,1550,2100,2500,2800
        self.shielded = False

        self.txposy = 0
        self.sound = playsound(self)
        self.level4_done = False
        self.update_lvl4 = 0
        self.lvl4_count = 0

        self.cutload()
        self.cut_seen1()
        pygame.time.wait(200)
        self.run()

    def run(self):
        self.playing = True
        while self.playing:
            self.clock.tick(fps)
            self.events()
            self.update()
            self.draw()
            


    def update(self):
        #self.now = pygame.time.get_ticks()
        #self.sheet = Sheet(spritesheet)
        
        if self.level == 1:
            self.one()
        elif self.level == 2:
            self.two()
        elif self.level == 3:
            self.three()
        elif self.level == 4:
            self.four()
        elif self.level == 5:
            self.survival_mode()
        self.gam.update()

    def events(self):
        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                if self.playing:
                    self.playing = False
                    self.running = False
            if e.type == pygame.KEYDOWN:
                print(e.unicode)
                if e.key == pygame.K_SPACE:
                    self.p.shoot()
                    playsound(self)
                    if self.helper_alive == True:
                        self.helper.shoot()
                if e.key == pygame.K_q:
                    if self.playing:
                        self.playing = False
                        self.running = False


                    
                    
                if e.key == pygame.K_p:
                    self.wait_for_key()
                    self.show_p_screen()

                if e.key == pygame.K_z:
                    self.sound.switchwep()
                    if self.rank == 0:
                        pass
                    if self.rank == 1:
                        if self.did_buy_wep1 and not self.did_buy_wep2 and not self.did_buy_wep3:
                            if self.wepon == 1:
                                self.wepon = 0
                            elif self.wepon == 0:
                                self.wepon = 1
                    elif self.rank == 2:
                        if self.did_buy_wep2 == True and self.did_buy_wep1:
                            if self.wepon == 1:
                                self.wepon = 2
                            elif self.wepon == 2:
                                self.wepon = 0
                            elif self.wepon == 0:
                                self.wepon = 1
                        elif self.did_buy_wep1 and not self.did_buy_wep2:
                            if self.wepon == 1:
                                self.wepon = 0
                            elif self.wepon == 0:
                                self.wepon = 1
                    elif self.rank == 3:
                        if self.did_buy_wep2 and self.did_buy_wep1 and self.did_buy_wep3:
                            if self.wepon == 1:
                                self.wepon = 2
                            elif self.wepon == 2:
                                self.wepon = 3
                            elif self.wepon == 3:
                                self.wepon = 0
                            elif self.wepon == 0:
                                self.wepon = 1
                        elif self.did_buy_wep2 == True and self.did_buy_wep1 and not self.did_buy_wep3:
                            if self.wepon == 1:
                                self.wepon = 2
                            elif self.wepon == 2:
                                self.wepon = 0
                            elif self.wepon == 0:
                                self.wepon = 1




    def draw(self):

        self.screen.blit(self.deep_space_pic,(0,0))
        if self.wepon == 0:
            self.switchy = green
        elif self.wepon == 1:
            self.switchy = blue
        elif self.wepon == 2:
            self.switchy = blurple
        elif self.wepon == 3:
            self.switchy = red
        elif self.wepon == 4:
            self.switchy = lightblue


        self.draw_text2(self.atex,'SCORE:  ' + str(self.score), white ,wth / 2,self.txposy)
        self.draw_text2( self.btex,'GALACTIC REVENUE:  ' +  str(self.coin_count) , blue ,wth / 4 , self.txposy + 30)
        self.draw_update()
        if self.level == 1:
            if self.current_time >= 2900 and self.current_time <= 3000:
                self.draw_text2(self.atex,'Boss: Jimp Captain - Rwulu',red,wth // 2, hgt // 2)
                self.draw_text2(self.atex,'APPROACHING',self.gorand, wth // 2  , hgt // 2 - 150)
        if self.level == 2:
            if self.current_time >= 2900 and self.current_time <= 3000:
                self.draw_text2(self.atex,'Boss: Jimp Top Captain - Klukka',red,wth // 2, hgt // 2)
                self.draw_text2(self.atex,'APPROACHING',self.gorand, wth // 2  , hgt // 2 - 150)
        if self.level == 3:
            if self.current_time >= 290 and self.current_time <= 600:
                self.draw_text2(self.atex,'Boss: Quod squade',red,wth // 2, hgt // 2)
                self.draw_text2(self.atex,'APPROACHING',self.gorand, wth // 2  , hgt // 2 - 150)
        if self.level == 4:
            if self.current_time >= 290 and self.current_time <= 600:
                self.draw_text2(self.atex,'Inialation Fleet',red,wth // 2, hgt // 2)
                self.draw_text2(self.atex,'APPROACHING',self.gorand, wth // 2  , hgt // 2 - 150)
        self.draw_text2(self.atex,'HP: ' + str(self.p.hp),red,40,550)
        self.draw_text2(self.atex, 'wpn: ' + str(self.wepon), self.switchy, 55, 580)
        self.gam.draw(self.screen)
        if self.level != 5:
            self.frontr.draw(self.screen)
            self.frontr.update()
        pygame.display.flip()
    def draw_update(self):

        self.gorand = random.choice([red,green,blue,white,pink,hotpink,junglegreen,purple,yellow])
        if self.current_time >= 50 and self.current_time <= 150:
            self.draw_text('ARDESTINE.ttf', 'LEVEL : ' +  str(self.level) , 70 , self.gorand ,wth - wth // 2 , hgt // 2)
        if self.level == 3:
            self.draw_text('aaa.ttf','boss kill count: ' + str(self.boss3_death_count),40,yellow,wth - 175,175)
        '''if self.level == 5:
            self.draw_text('aaa.ttf' str(self.next_wave), 40, green, wth // 2, hgt // 2)'''




            

    def show_start_screen(self):
        pygame.mixer.init()
        pygame.mixer.music.load('sounds\\dark.mp3')
        self.screen.fill(black)
        self.screen.blit(self.sceen_start,(0,0))
        pygame.display.update()
        self.wait_for_key()
        self.start_sceen_text_color = black
        self.start_sceen_text_color1 = grey
        self.firstfill = white 
        self.stc = pygame.sprite.Group()
        self.o123 = wth / 2
        self.o321 = wth / 2
        self.o456 = wth / 2
        self.tima = 0
        self.upa = 1
        self.sph = - 600
        self.stx1 = 'BUT ALL WAS NOT AS THE PICTURE PAINTED'
        self.stxs = 15
        PLANET1 = pygame.image.load('start_planet2.png').convert()
        PLANET2 = pygame.image.load('start_planet3.png').convert()
        PLANET3 = pygame.image.load('start_planet4.png').convert()
        PLANET4 = pygame.image.load('start_planet5.png').convert()
        PLANET5 = pygame.image.load('lastonelol.png').convert()
        pygame.mixer.music.play()
        self.p_running = True
        while self.p_running:
            self.clock.tick(fps)
            #print(str(self.tima))
            for e in pygame.event.get():
                if e.type == pygame.QUIT:
                    self.p_running = False
                    self.running = False
                if e.type == pygame.KEYUP:
                    pygame.mixer.music.stop()
                    self.p_running = False
            self.start_sceen_tx += -1
            self.start_sceen_tx1 += -1
            self.tima += self.upa
            self.screen.fill(self.firstfill)
            
            
            if self.start_sceen_tx == 400:
                for i in range(300):
                    self.backs = live_stars()
                    self.stc.add(self.backs)
                    
            
            if self.start_sceen_tx <= 300 :
                self.start_sceen_tx = 300
                self.start_sceen_text_color = white
                self.firstfill = black
            self.stc.draw(self.screen)
            if self.start_sceen_tx <= 399:
                self.screen.blit(self.start_planet, (0,self.sph))
                self.sph += 2
            if self.sph >= 0:
                self.sph = 0
            self.draw_text('bob.ttf','IN ALL OF THE MILKY - WAY, THERE WAS NO WORLD ',15,self.start_sceen_text_color, self.o123,self.start_sceen_tx)
            self.draw_text('bob.ttf','MORE WONDEROUS THAN KAR-PA.',15,self.start_sceen_text_color, self.o123,self.start_sceen_tx + 20)
            self.draw_text('bob.ttf','ON KAR-PA, NO TWO PEOPLE WERE MORE LOVED ',15,self.start_sceen_text_color, self.o321,self.start_sceen_tx + 50)
            self.draw_text('bob.ttf','THAN KING YOMMT AND HIS QUEEN AND CONFADENT',15,self.start_sceen_text_color, self.o321,self.start_sceen_tx + 70)
            self.draw_text('bob.ttf','HER LADYSHIP, REHTAEH',15,self.start_sceen_text_color, self.o321,self.start_sceen_tx + 100)
            self.draw_text('bob.ttf',self.stx1,self.stxs,self.start_sceen_text_color1, self.o456,self.start_sceen_tx1)
            if self.tima >= 450:
                self.o123 = -600
                self.o321 = -600
            '''if self.o321 >= wth  + 50:
                self.o321 = 50
            if self.o123 <= -50:
                self.o123 = -50'''
            if self.start_sceen_tx1 <= wth / 2:
                self.stx1 = 'THERE WAS ONE WHO ENVIED THIER HAPPYNESS'
                self.start_sceen_text_color1 = red
                self.start_sceen_tx1 = wth / 2
            if self.tima >= 540:
                self.stx1 = 'AND WOULD TAKE IT ALL'
                self.stxs += 1
            if self.stxs >= 35:
                self.stxs = 35
            if self.tima == 600:
                for self.backs in self.stc:
                    self.backs.kill()
                
            
            if self.sph >= 0 and self.tima >= 600:
                self.start_planet = PLANET1
                self.start_sceen_text_color1 = green 
                self.start_planet.set_colorkey(black)
            if self.sph >= 0 and self.tima >= 610:
                self.start_planet = PLANET2
                self.start_planet.set_colorkey(black)
            if self.sph >= 0 and self.tima >= 620:
                self.start_planet = PLANET3
                self.start_sceen_text_color1 = black
                self.firstfill = white
                self.start_planet.set_colorkey(black)
            if self.sph >= 0 and self.tima >= 630:
                self.start_planet = PLANET4
                self.start_planet.set_colorkey(black)
            if self.sph >= 0 and self.tima >= 640:
                self.start_planet = PLANET5
                self.start_planet.set_colorkey(black)
                self.start_sceen_text_color1 = red
                self.firstfill = black
            if self.tima == 640:
                for i in range(300):
                    self.backs = live_stars()
                    self.stc.add(self.backs)
            if self.tima >= 650:
                self.stx1 = 'AVENGE'
                self.start_sceen_text_color = random.choice((red,hotpink))
                self.sph -= 10
            self.stc.update()  
            pygame.display.flip()
        
    

    def show_p_screen(self):
        self.ps_running = True
        while self.ps_running:
            self.clock.tick(fps)
            for e in pygame.event.get():
                if e.type == pygame.QUIT:
                    self.ps_running = False
                    self.running = False
                if e.type == pygame.KEYUP:
                    self.pause_tx_size = 1
                    self.ps_running = False
            self.pause_tx_size += 1
            if self.pause_tx_size >= 50:
                self.pause_tx_size = 50
            self.screen.fill(green)
            self.draw_text('ARDESTINE.ttf','PAUSE',self.pause_tx_size,black,wth / 2, hgt / 2)
            pygame.display.flip()
        

    def show_go_screen(self):
        self.screen.fill(white)
        self.draw_text('r.ttf','game over', 30, black, wth / 2, hgt / 2)
        pygame.display.flip
        self.wait_for_key()

    def wait_for_key(self):
        waiting = True
        while waiting:
            self.clock.tick(fps)
            for e in pygame.event.get():
                if e.type == pygame.QUIT:
                    waiting = False
                    self.running == False
                if e.type == pygame.KEYUP:
                    waiting = False
            
            pygame.display.update()


    def draw_text(self,font, text, size,color,x,y):

        font = pygame.font.Font(font, size)
        text_surface = font.render(text,True,color)
        text_rect = text_surface.get_rect()
        text_rect.midtop = (x,y)
        self.screen.blit(text_surface, text_rect)
    def draw_text2(self,font, text,color,x,y):


        text_surface = font.render(text,True,color)
        text_rect = text_surface.get_rect()
        text_rect.midtop = (x,y)
        self.screen.blit(text_surface, text_rect)


    def one(self):

        self.play_check = True
        self.game_play_screen()
        self.coinhits = pygame.sprite.groupcollide(self.player,self.gets,False,True,pygame.sprite.collide_mask)
        now = pygame.time.get_ticks()
        if now - self.update_it > 10:
            self.update_it = now
            self.current_time += 1
    
        if self.current_time == 150 or self.current_time == 300 or self.current_time == 450 or self.current_time == 600 or self.current_time == 800 or self.current_time == 1100 or self.current_time == 1500 or self.current_time == 1800 or self.current_time == 2300 or self.current_time == 2650 or self.current_time == 2800: # or self.current_time == 3000 or self.current_time == 3001 or self.current_time == 3002:
            self.c = Powerup()
            self.gam.add(self.c)
            self.gets.add(self.c)
            for i in range(3):
                self.rock = Meteor(self)
                self.gam.add(self.rock)
                self.mobs.add(self.rock)
        if self.current_time == self.rand_time:
            d = help_drop(self)
            self.gam.add(d)
            self.player.add(d)
        if self.current_time == self.rand_time2:
            d = help_drop2(self)
            self.gam.add(d)
            self.player.add(d)

        if self.current_time == 3000:
            pygame.mixer.Channel(0).stop()
            pygame.mixer.Channel(0).play(pygame.mixer.Sound('music\\thy.wav'))
            self.live_planet.alive = False
            self.mobs.add(self.b)
            self.gam.add(self.b)

        if self.boss1_hp <=0 and self.level == 1 and self.b.current_frame >= 23 and self.current_time > 310:
            self.a_screen()
            self.playing = False

        if self.coinhits:
            self.coin_count += 1
            self.sound.exept()
        self.end()
    def two(self):

        self.play_check = True
        self.game_play_screen()
        self.boss1_hp = 20
        self.coinhits = pygame.sprite.groupcollide(self.player,self.gets,False,True,pygame.sprite.collide_mask)
        now = pygame.time.get_ticks()
        if now - self.update_it > 10:
            self.update_it = now
            self.current_time += 1

        if self.current_time == self.rand_time2:
            d = help_drop2(self)
            self.gam.add(d)
            self.player.add(d)

        if self.current_time == self.rand_time:
            d = help_drop(self)
            self.gam.add(d)
            self.player.add(d)

        if self.current_time == 150 or self.current_time == 300 or self.current_time == 450 or self.current_time == 600 or self.current_time == 800 or self.current_time == 1100 or self.current_time == 1500 or self.current_time == 1800 or self.current_time == 2300 or self.current_time == 2650 or self.current_time == 2800 or self.current_time == 3000 or self.current_time == 3001 or self.current_time == 3002:
            self.c = Powerup()
            self.gam.add(self.c)
            self.gets.add(self.c)
        if self.current_time == 100:
            self.m3 = Mob3(self)
            self.gam.add(self.m3)
            self.mobs.add(self.m3)

        if self.current_time == 1000 or self.current_time == 2000 or self.current_time == 3000:
            for i in range(2):
                a = Alex001(self)
                self.mobs.add(a)
                self.gam.add(a)
        if self.current_time == 300 or self.current_time == 900 or self.current_time == 1500 or self.current_time == 2200:
            for i in range(5):
                n = Mob2(self)
                self.gam.add(n)
                self.mobs.add(n)

        if self.current_time == 600 or self.current_time == 1200 or self.current_time == 1900 or self.current_time == 2600:
            for i in range(2):
                m = Mob(self)
                self.mobs.add(m)
                self.gam.add(m)
        if self.current_time == 3000:
            self.b2 = Boss3(self)
            self.gam.add(self.b2)
            self.mobs.add(self.b2)
        if self.coinhits:
            self.coin_count += 1
            self.sound.exept()

        self.end()
        if self.boss2_hp <=0 and self.level == 2 and self.b2.current_frame >= 23:
            self.a_screen()
            self.playing = False
    def three(self):
        self.play_check = True
        self.game_play_screen()
        self.boss1_hp = 20
        self.coinhits = pygame.sprite.groupcollide(self.player, self.gets, False, True,pygame.sprite.collide_mask)

        self.end()
        now = pygame.time.get_ticks()
        if now - self.update_it > 10:
            self.update_it = now
            self.current_time += 1
        if self.current_time == self.rand_time:
            d = help_drop(self)
            self.gam.add(d)
            self.player.add(d)
        if self.current_time == self.rand_time2:
            d = help_drop2(self)
            self.gam.add(d)
            self.player.add(d)
        if self.current_time == 150 or self.current_time == 300 or self.current_time == 450 or self.current_time == 600 or self.current_time == 800 or self.current_time == 1100 or self.current_time == 1500 or self.current_time == 1800 or self.current_time == 2300 or self.current_time == 2650 or self.current_time == 2800:
            self.c = Powerup()
            self.gam.add(self.c)
            self.gets.add(self.c)
            for i in range(1):
                m = Meteora(self)
                self.gam.add(m)
                self.mobs.add(m)
        if self.current_time == 300:
            for i in range(1):
                b = Bosslvl3(self)
                self.gam.add(b)
                self.mobs.add(b)
                self.boss3_kills.add(b)
                self.boss3_spawn = True
        if self.boss3_spawn == True:
            if len(self.boss3_kills) < 1:
                b = Bosslvl3(self)
                self.gam.add(b)
                self.mobs.add(b)
                self.boss3_kills.add(b)

        if self.boss3_death_count >= 4 or self.current_time == 3500:
            self.a_screen()
            self.playing = False
        if self.coinhits:
            self.sound.exept()
            self.coin_count += 1
        self.end()
    def four(self):
        self.play_check = True
        self.game_play_screen()
        self.coinhits = pygame.sprite.groupcollide(self.player, self.gets, False, True, pygame.sprite.collide_mask)
        if self.coinhits:
            self.sound.exept()
            self.coin_count += 1
        self.end()
        now = pygame.time.get_ticks()
        if now - self.update_it > 10:
            self.update_it = now
            self.current_time += 1
        if self.current_time == self.rand_time2:
            d = help_drop2(self)
            self.gam.add(d)
            self.player.add(d)
        if self.current_time == self.rand_time:
            d = help_drop(self)
            self.gam.add(d)
            self.player.add(d)
        if self.current_time == 10:
            self.port = Portal(self)
            self.frontr.add(self.port)
            self.frontr.add(self.p)
            self.frontr.move_to_back(self.port)
            self.frontr.move_to_front(self.p)
            self.txposy = hgt - 100
        if self.current_time == 150 or self.current_time == 300 or self.current_time == 450 or self.current_time == 600 or self.current_time == 800 or self.current_time == 1100 or self.current_time == 1500 or self.current_time == 1800 or self.current_time == 2300 or self.current_time == 2650 or self.current_time == 2600:
            self.c = Powerup()
            self.gam.add(self.c)
            self.gets.add(self.c)
            for i in range(1):
                m = Meteora(self)
                self.gam.add(m)
                self.mobs.add(m)
        if self.current_time == 300:

            for i in range(5):
                b = Boss4(self)
                self.gam.add(b)
                self.mobs.add(b)
                self.keep_coming.add(b)
                self.frontr.add(b)
                self.frontr.move_to_front(b)

        if self.current_time == 500 or self.current_time == 800 or self.current_time == 1100 or self.current_time == 1400 or self.current_time == 1700 or self.current_time == 2000 or self.current_time == 2300 or self.current_time == 2600 or self.current_time == 2900:

            if len(self.keep_coming) < 5:
                b1 = Boss4(self)
                self.gam.add(b1)
                self.keep_coming.add(b1)
                self.frontr.add(b1)
                self.frontr.move_to_front(b1)

        if self.level4_done == True:
            for i in self.mobs:
                i.kill()
            for i in self.keep_coming:
                i.kill()

            nows = pygame.time.get_ticks()
            if nows - self.update_lvl4 > 1000 and self.port.hits:
                self.update_lvl4 = nows
                self.lvl4_count += 1
                if self.lvl4_count == 3:
                    self.a_screen()
                    self.playing = False


    def a_screen(self):
        self.play_check = False
        if self.level != 5:
            self.screen.fill(pumpkin)
            if self.level != 4:
                self.draw_text2(self.atex,'you just kicked level'+ str(self.level) + 'ass',blurple,wth / 2, hgt / 10)
                self.draw_text2(self.atex, 'press c to continue to level ' + str(self.level + 1), blurple, wth // 2 , hgt // 10 + 50)
            if self.level == 4:
                self.draw_text2(self.atex, 'you just kicked level' + str(self.level) + 'in the dick', 30, blurple, wth / 2, hgt / 10)
                self.draw_text2(self.atex, 'press c to continue to SURVIVAL MODE', blurple, wth // 2,
                               hgt // 10 + 50)
            self.draw_text('aaa.ttf', 'Galactic revenue: ' + str(self.coin_count),30,blurple,wth / 4, hgt // 10 + 100)
            self.draw_text('aaa.ttf', 'Score: ' + str(self.score),30,blurple,wth/4,hgt//10 + 150)
            self.draw_text('aaa.ttf', 'replay LEVEL ' + str(self.level)  +  ' press r',30,blurple,wth/4,hgt// 10 + 200)
            self.draw_text('aaa.ttf', 'travel to a SPACEMART press `s` ',30,blurple,wth/4,hgt// 10 + 250)
        waiting = True
        while waiting:
            self.clock.tick(fps)
            for e in pygame.event.get():
                if e.type == pygame.QUIT:
                    waiting = False
                    self.running = False
                if e.type == pygame.KEYDOWN:
                    if e.key == pygame.K_r:
                        self.playing = False
                        waiting = False
                    if e.key == pygame.K_c:
                        for i in self.mobs:
                            i.kill()
                        if self.level >= 2 and self.level < 4:
                            self.boss3_death_count = 0
                        self.level += 1
                        if self.level == 4:
                            self.deep_space_pic = pygame.image.load('bg5.jpg').convert()
                            self.deep_space_pic = pygame.transform.scale(self.deep_space_pic, (wth, hgt))
                            self.run_back_once = True
                        waiting = False
                        self.playing = False
                    if e.key == pygame.K_s:
                        self.spacemart()
                        waiting = False
                        self.playing = False
                        
                        
            pygame.display.update()
    def end(self):
        if self.p.gh == 6:
            self.p.kill()
            self.p.alive = True
            self.gam.add(self.p)
            self.player.add(self.p)
            self.show_go_screen()
            self.level = 1
            self.coin_count = 0
            self.current_time = 0
            self.played = True
            self.playing = False
            
                
    def backround_layer(self):

        if self.level == 1:
            for i in range(200):
                self.live_backround = live_stars()
                self.gam.add(self.live_backround)
            for i in range(1):
                self.live_planet = live_planet_turn(self)
                self.gam.add(self.live_planet)

        if self.level == 2:
            for i in range(200):
                self.live_backround = live_stars()
                self.gam.add(self.live_backround)
            for i in range(3):
                self.objects = live_objects(self)
                self.gam.add(self.objects)
        if self.level == 3:
            for i in range(200):
                self.live_backround = live_stars()
                self.gam.add(self.live_backround)
            for i in range(2):
                self.new_space = space_town(self)
                self.gam.add(self.new_space)
        if self.level == 1:
            self.deep_space_pic = pygame.image.load(BAXONE).convert()
        if self.level == 2:
            self.deep_space_pic = pygame.image.load(BAXTWO).convert()
        if self.level == 3:
            self.deep_space_pic = pygame.image.load(BAXTHREE).convert()
        if self.level == 4:
            self.deep_space_pic = pygame.image.load(BAXFOUR).convert()
        if self.level == 5:
            self.deep_space_pic = pygame.image.load(BAXFIVE).convert()


        self.deep_space_pic = pygame.transform.scale(self.deep_space_pic, (wth, hgt))
        self.run_back_once = True




    def cutload(self):
        self.ONE = pygame.image.load('seen1.png')
        self.TWO = pygame.image.load('seen2.png')
        self.THREE = pygame.image.load('seen3.png')
        self.FOUR = pygame.image.load('seen6.png')
        self.FIVE = pygame.image.load('seen7.png')
        self.SIX = pygame.image.load('seen4.png')
        self.SEVEN = pygame.image.load('seen8.png')
        self.EIGHT = pygame.image.load('seen5.png')
        self.NINE = pygame.image.load('seen9.png')
        self.TEN = pygame.image.load('seen19.png')
        self.ELEV = pygame.image.load('seen11.png')
        self.TWELVE = pygame.image.load('seen12.png')
        self.THIRT  = pygame.image.load('seen13.png')




    def cut_seen1(self):
        self.screen.fill(black)
        if self.level == 1:
            self.wait_for_key()
            self.screen.blit(self.ONE,(0,0))
            self.wait_for_key()
            self.screen.fill(black)
            self.screen.blit(self.TWO,(0,0))
            self.wait_for_key()
            self.screen.fill(black)
            self.screen.blit(self.THREE,(0,0))
            self.wait_for_key()
        if self.level == 2:
            self.wait_for_key()
            self.screen.blit(self.FOUR,(0,0))
            self.wait_for_key()
            self.screen.blit(self.FIVE,(0,0))
            self.wait_for_key()
            self.screen.blit(self.SIX,(0,0))
            self.draw_text('aaa.ttf','There is no one....',40,black,wth // 2, hgt // 2)
            self.wait_for_key()

        if self.level == 3:
            self.wait_for_key()
            self.draw_text('aaa.ttf', 'Yommt traveled the empty space alone', 40, white, wth // 2, hgt // 2)
            self.wait_for_key()
            self.screen.blit(self.SEVEN,(0,0))
            self.wait_for_key()
            self.screen.blit(self.EIGHT,(0,0))
            self.wait_for_key()
            self.screen.blit(self.EIGHT,(0,0))
            self.draw_text('aaa.ttf', 'I just want to go home....', 40, white, wth // 2, hgt // 2)
            self.wait_for_key()
            self.screen.fill(black)
            self.screen.blit(self.NINE,(0,0))
            self.wait_for_key()
            self.screen.blit(self.TEN,(0,0))
            self.wait_for_key()

        if self.level == 4:
            self.wait_for_key()
            self.draw_text('aaa.ttf', 'level four ', 40, white, wth // 2, hgt // 2)
            self.draw_text('aaa.ttf', 'the farthest reaches', 40, white, wth // 2, hgt // 2 + 50)
            self.wait_for_key()
            self.screen.blit(self.ELEV,(0,0))
            self.wait_for_key()
            self.screen.blit(self.TWELVE,(0,0))
            self.wait_for_key()
        if self.level == 5:
            self.wait_for_key()
            self.screen.blit(self.THIRT,(0,0))

            self.wait_for_key()
    def spacemart(self):
        pygame.mixer.Channel(0).play(pygame.mixer.Sound('music\\Rockmenutrack.ogg'))
        self.sound.openmart()
        self.storestock = pygame.sprite.Group()
        self.play_check = False
        self.did_check = 0
        for i in range(200):
            self.stars = live_stars()
            self.storestock.add(self.stars)
        self.tex = tex(wth // 2, hgt // 4,self)
        self.tex.image = pygame.transform.scale(self.tex.image,(400,500))
        spacemartbax = pygame.image.load('space005.png')
        self.tex2 = tex(25,hgt // 4,self)
        self.tex3 = tex(25, hgt // 4, self)
        self.tex4 = tex(25, hgt // 4, self)
        self.tex5 = tex(25, hgt // 4, self)

        self.texa = tex(220, hgt // 4, self)
        waiting = True
        while waiting:
            self.clock.tick(fps)
            for e in pygame.event.get():
                if e.type == pygame.QUIT:
                    waiting = False
                    self.running = False
                if e.type == pygame.KEYDOWN:
                    if e.key == pygame.K_c:
                        self.sound.closemart()
                        self.level += 1
                        if self.level >= 2 and self.level < 4:
                            self.boss3_death_count = 0
                        if self.level == 4:
                            self.deep_space_pic = pygame.image.load('bg5.jpg').convert()
                            self.deep_space_pic = pygame.transform.scale(self.deep_space_pic, (wth, hgt))
                            self.run_back_once = True
                        self.playing = False
                        waiting = False
                    if e.key == pygame.K_q:
                        self.playing = False
                        self.running =False
                        waiting = False
                    if e.key == pygame.K_r:
                        self.sound.closemart()
                        self.playing = False
                        waiting = False
                    if e.key == pygame.K_x:

                        if self.rank == 0 and self.score >= 100:
                            self.sound.exept()
                            self.rank += 1
                            self.score -= 100
                        elif self.rank == 1 and self.score >= 200 and self.wepon == 1 and self.did_check == 0:
                            self.sound.exept()
                            self.did_check += 1
                            self.rank += 1
                            self.score -= 200
                        elif self.rank == 2 and self.score >= 300 and self.wepon == 2:
                            self.sound.exept()
                            self.did_check += 1
                            self.rank += 1
                            self.score -= 300
                        else:
                            self.sound.button()

                    if e.key == pygame.K_z:

                        if self.rank == 1 and self.coin_count >= 10 and self.wepon == 0 and self.ship == 1:
                            self.did_buy_wep1 = True
                            self.sound.exept()
                            self.wepon = 1
                            self.coin_count -= 10
                        elif self.rank == 2 and self.coin_count >= 20 and self.wepon == 1 and self.ship == 1:
                            self.did_buy_wep2 = True
                            self.sound.exept()
                            self.wepon = 2
                            self.coin_count -= 20
                        elif self.rank == 3 and self.coin_count >= 40 and self.ship ==1 and self.wepon == 2:
                            self.did_buy_wep3 = True
                            self.sound.exept()
                            self.wepon = 3
                            self.coin_count -= 40
                        elif self.rank == 3 and self.wepon == 3 and self.ship == 1 and self.coin_count >= 50:
                            self.sound.exept()
                            self.ship = 2
                            self.coin_count -= 50
                        else:
                            self.sound.button()

            self.screen.blit(spacemartbax,(0,0))
            if self.play_check == False:
                self.storestock.add(self.tex)
            else:
                self.tex.kill()



            if self.rank == 0:
                self.draw_text('aaa.ttf','100 score points to next rank',25,lightblue, wth // 4 , hgt - 200)
                self.draw_text('aaa.ttf', 'Current rank has no upgrades', 20, lightblue, wth // 4 , hgt - 150 )
            if self.rank == 1 and self.wepon == 0:
                self.draw_text('aaa.ttf', 'next rank not available', 20, lightblue, wth // 4 , hgt - 200 )
                self.draw_text('aaa.ttf', '(10g)Weapon upgrade available', 25, lightblue,  wth // 4 , hgt - 150)
            if self.rank == 1 and self.wepon == 1:
                self.draw_text('aaa.ttf', '200 score points to next rank', 25, lightblue, wth // 4 , hgt - 200 )
                self.draw_text('aaa.ttf', 'Current rank has no upgrades', 20, lightblue,  wth // 4 , hgt - 150)
            if self.rank == 2 and self.wepon == 1:
                self.draw_text('aaa.ttf', 'next rank not available', 20, lightblue,  wth // 4 , hgt - 200)
                self.draw_text('aaa.ttf', '(20g)Weapon upgrade available', 25, lightblue,  wth // 4 , hgt - 150)
            if self.rank == 2 and self.wepon == 2:
                self.draw_text('aaa.ttf', '300 score points to next rank', 25, lightblue, wth // 4 , hgt - 200 )
                self.draw_text('aaa.ttf', 'current rank has no upgrades', 20, lightblue,  wth // 4 , hgt - 150)
            if self.rank == 3 and self.wepon == 2:
                self.draw_text('aaa.ttf', 'next rank not available', 20, lightblue, wth // 4 , hgt - 200)
                self.draw_text('aaa.ttf', '(40g)Weapon upgrade available', 25, lightblue, wth // 4 , hgt - 150 )
            if self.rank == 3 and self.wepon == 3 and self.ship == 1:
                self.draw_text('aaa.ttf', 'next rank not available', 20, lightblue, wth // 4 , hgt - 200 )
                self.draw_text('aaa.ttf', '(60g)new ship available', 25, lightblue,  wth // 4 , hgt - 150)
            if self.rank == 3 and self.ship == 2:
                self.draw_text('aaa.ttf', '1000 score points to next rank', 25, lightblue, wth // 4, hgt - 200)
                self.draw_text('aaa.ttf', 'current rank has no upgrades', 20, lightblue, wth // 4, hgt - 150)




            self.tex.draw_text2('`x` to exept rank ',30,200  ,240)
            self.tex.draw_text2('`z` to exept upgrade' ,30,200 ,270)
            self.tex.draw_text2('`c` to continue on',30,200 , 300)
            self.tex.draw_text2('`r` to replay last level',30,200 ,330)

            self.draw_text('aaa.ttf','RANK: ' + str(self.rank), 40, blue,100,0)
            self.draw_text('aaa.ttf','weapon: ' + str(self.wepon), 40, blue,400,0)
            self.draw_text2(self.btex, 'Galatic revenue: ' + str(self.coin_count), yellow, 170, 50)
            self.draw_text('aaa.ttf', 'Score Points: ' + str(self.score), 40, pumpkin, 500, 50)

            self.tex.weps()

            if self.rank == 0:
                self.storestock.add(self.tex2)
                self.storestock.add(self.texa)
                self.texa.rank_stats()
                self.tex2.draw_text('CURRENT RANK', 20)
                self.t1 = 'Guppy'
                self.t2 = 'Guppy stats...'
                self.t3 = 'current upgrades 0'
                self.t4 = 'hp = 1'
                self.tex2.draw_text(self.t1, 40)
                self.tex2.draw_text(self.t2, 60)
                self.tex2.draw_text(self.t3, 80)
                self.tex2.draw_text(self.t4, 100)
            else:
                self.tex2.kill()

            if self.rank == 1:
                self.storestock.add(self.tex3)
                self.storestock.add(self.texa)
                self.texa.rank_stats()
                self.tex3.draw_text('CURRENT RANK', 20)
                self.t1 = 'Bag boy'
                self.t2 = 'Bag boy stats...'
                self.t3 = 'current upgrades 1'
                self.t4 = 'hp = 2'
                self.tex3.draw_text(self.t1, 40)
                self.tex3.draw_text(self.t2, 60)
                self.tex3.draw_text(self.t3, 80)
                self.tex3.draw_text(self.t4, 100)
            else:
                self.tex3.kill()

            if self.rank == 2:
                self.storestock.add(self.tex4)
                self.storestock.add(self.texa)
                self.texa.rank_stats()
                self.tex4.draw_text('CURRENT RANK', 20)
                self.t1 = 'Small town hero'
                self.t2 = 'small town hero stats...'
                self.t3 = 'current upgrades 1'
                self.t4 = 'hp = 2'
                self.t5 = 'bomb upgrade now available'

                self.tex4.draw_text(self.t1, 40)
                self.tex4.draw_text(self.t2, 60)
                self.tex4.draw_text(self.t3, 80)
                self.tex4.draw_text(self.t4, 100)
                self.tex4.draw_text(self.t5, 120)
            else:
                self.tex4.kill()
            if self.rank == 3:
                self.storestock.add(self.tex5)
                self.storestock.add(self.texa)
                self.texa.rank_stats()
                self.tex5.draw_text('CURRENT RANK', 20)
                self.t1 = 'moms fav milk man'
                self.t2 = 'moms fav milk man stats...'
                self.t3 = 'current upgrades 3'
                self.t4 = 'hp = 2'
                self.t5 = 'time 4 a new ship!!!'

                self.tex5.draw_text(self.t1, 40)
                self.tex5.draw_text(self.t2, 60)
                self.tex5.draw_text(self.t3, 80)
                self.tex5.draw_text(self.t4, 100)
                self.tex5.draw_text(self.t5, 120)
            else:
                self.tex5.kill()

            self.storestock.draw(self.screen)
            self.storestock.update()
            pygame.display.update()
        
    def game_play_screen(self):
        if self.level != 5:
            if self.current_time == 5:

                self.tx4 = tex(wth - 205, hgt // 2 + 100, self)


                self.gam.add(self.tx4)
                self.tx4.draw_text('game stuff', 20)
            if self.current_time == 50:
                self.tx4.draw_text('Times died: ' + str(self.times_died), 40)
            if self.current_time == 150:
                self.tx4.draw_text('Story: ' , 80)
            if self.current_time == 200:
                if self.level == 1:

                    self.tx4.draw_text('A world at sedge!!!!', 100)
                if self.level == 2:
                    self.tx4.draw_text('A wonderer of nothing!!!!',100)

    def survival_mode(self):

        self.play_check = True
        #self.game_play_screen()
        self.coinhits = pygame.sprite.groupcollide(self.player, self.gets, False, True, pygame.sprite.collide_mask)
        now = pygame.time.get_ticks()

        if now - self.update_it > 10:
            self.update_it = now
            self.current_time += 1
        if self.current_time == self.rand_time1:
            d = help_drop(self)
            self.gam.add(d)
            self.player.add(d)
        if self.current_time == self.rand_time2:
            d = help_drop2(self)
            self.gam.add(d)
            self.player.add(d)

        #put waves here
        if self.next_wave == 0:
            self.wave0()
        if self.next_wave == 1:
            self.wave1()
        if self.next_wave == 2:
            self.wave3()
        if self.next_wave == 3:
            self.wave4()
        if self.next_wave == 4:
            self.wave0()
            self.wave1()
        if self.next_wave == 5:
            self.wave0()
            self.wave3()
        if self.next_wave > 5:
            self.wave0()
            self.wave1()
            self.wave3()
            self.wave4()








        self.end()
    def pick_your_level(self):
        waiting = True
        while waiting:
            self.clock.tick(fps)
            for e in pygame.event.get():
                if e.type == pygame.QUIT:
                    waiting = False
                    self.running = False
                if e.type == pygame.KEYDOWN:
                    if e.key == pygame.K_1:
                        self.level =1
                        waiting = False
                    if e.key == pygame.K_2:
                        self.level =2
                        waiting = False
                    if e.key == pygame.K_3:
                        self.level = 3
                        waiting = False
                    if e.key == pygame.K_4:
                        self.level = 4
                        waiting = False
                    if e.key == pygame.K_5:
                        self.level = 5
                        waiting = False


            self.screen.fill(green)
            self.draw_text('ARDESTINE.ttf','choose level: type 1,2,3,4 or 5',40, black, wth / 2, hgt / 2)
            pygame.display.flip()

    def wave0(self):
        if self.current_time == 150 or self.current_time == 300 or self.current_time == 450 or self.current_time == 600 or self.current_time == 800 or self.current_time == 1100 or self.current_time == 1500 or self.current_time == 1800 or self.current_time == 2300 or self.current_time == 2650 or self.current_time == 2800:
            self.c = Powerup()
            self.gam.add(self.c)
            self.gets.add(self.c)
            for i in range(1):
                m = Meteora(self)
                self.gam.add(m)
                self.mobs.add(m)
        if self.current_time == 250:
            pygame.mixer.Channel(0).stop()
            pygame.mixer.Channel(0).play(pygame.mixer.Sound('sounds\\thy.wav'))
            b = Boss3(self)
            self.mobs.add(b)
            self.gam.add(b)
    def wave1(self):
        if self.current_time == 150 or self.current_time == 300 or self.current_time == 450 or self.current_time == 600 or self.current_time == 800 or self.current_time == 1100 or self.current_time == 1500 or self.current_time == 1800 or self.current_time == 2300 or self.current_time == 2650 or self.current_time == 2800 or self.current_time == 3000 or self.current_time == 3001 or self.current_time == 3002:
            self.c = Powerup()
            self.gam.add(self.c)
            self.gets.add(self.c)
        if self.current_time == 100:
            self.m3 = Mob3(self)
            self.gam.add(self.m3)
            self.mobs.add(self.m3)

        if self.current_time == 1000 or self.current_time == 2000 or self.current_time == 3000:
            for i in range(2):
                a = Alex001(self)
                self.mobs.add(a)
                self.gam.add(a)
        if self.current_time == 300 or self.current_time == 900 or self.current_time == 1500 or self.current_time == 2200:
            for i in range(5):
                n = Mob2(self)
                self.gam.add(n)
                self.mobs.add(n)

        if self.current_time == 600 or self.current_time == 1200 or self.current_time == 1900 or self.current_time == 2600:
            for i in range(2):
                m = Mob(self)
                self.mobs.add(m)
                self.gam.add(m)
        if self.current_time == 2999:
            self.b2 = Boss3(self)
            self.gam.add(self.b2)
            self.mobs.add(self.b2)
    def wave3(self):
        if self.current_time == 299:
            for i in range(4):
                b = Bosslvl3(self)
                self.gam.add(b)
                self.mobs.add(b)
        if self.current_time == 150 or self.current_time == 300 or self.current_time == 450 or self.current_time == 600 or self.current_time == 800 or self.current_time == 1100 or self.current_time == 1500 or self.current_time == 1800 or self.current_time == 2300 or self.current_time == 2650 or self.current_time == 2800:
            self.c = Powerup()
            self.gam.add(self.c)
            self.gets.add(self.c)
            for i in range(2):
                m = Meteora(self)
                self.gam.add(m)
                self.mobs.add(m)
    def wave4(self):
        if self.current_time == 500 or self.current_time == 800 or self.current_time == 1100 or self.current_time == 1400 or self.current_time == 1700 or self.current_time == 2000 or self.current_time == 2300 or self.current_time == 2600 or self.current_time == 2900:
            for i in range(5):
                b = Bosslvl3(self)
                self.gam.add(b)
                self.mobs.add(b)
        self.wave0()
    def credits(self):
        ENDS = pygame.image.load('crt.png')

        waiting = True
        while waiting:
            for e in pygame.event.get():
                if e.type == pygame.QUIT:
                    waiting = False
                    self.playing = False
                    self.running = False
                if e.type == pygame.KEYUP:
                    waiting = False
            self.play_credits -= 1
            self.screen.blit(ENDS,(0,self.play_credits))
            pygame.display.flip()
    def credits2(self):
        ENDS = pygame.image.load('crt2.png')

        waiting = True
        while waiting:
            for e in pygame.event.get():
                if e.type == pygame.QUIT:
                    waiting = False
                    self.playing = False
                    self.running = False
                if e.type == pygame.KEYUP:
                    waiting = False
            self.play_credits -= 1
            self.screen.blit(ENDS,(0,self.play_credits))
            pygame.display.flip()

    def last_min_tuches(self):
        self.sheetb1 = Sheet(BOSS1)
        self.Lightbullet = [pygame.image.load(LIGHTING1),
                        pygame.image.load(LIGHTING2),
                        pygame.image.load(LIGHTING3),
                        pygame.image.load(LIGHTING4),
                        pygame.image.load(LIGHTING5),
                        pygame.image.load(LIGHTING6),
                        pygame.image.load(LIGHTING7),
                        pygame.image.load(LIGHTING8),
                        pygame.image.load(LIGHTING9),
                        pygame.image.load(LIGHTING10),
                        pygame.image.load(LIGHTING11),
                        pygame.image.load(LIGHTING12),
                        pygame.image.load(LIGHTING13),
                        pygame.image.load(LIGHTING14),
                        pygame.image.load(LIGHTING15),
                        pygame.image.load(LIGHTING16),
                        pygame.image.load(LIGHTING17)]

        self.boss_blows = [pygame.image.load('expl_02_0000.png'),
                      pygame.image.load('expl_02_0001.png'),
                      pygame.image.load('expl_02_0002.png'),
                      pygame.image.load('expl_02_0003.png'),
                      pygame.image.load('expl_02_0004.png'),
                      pygame.image.load('expl_02_0005.png'),
                      pygame.image.load('expl_02_0006.png'),
                      pygame.image.load('expl_02_0007.png'),
                      pygame.image.load('expl_02_0008.png'),
                      pygame.image.load('expl_02_0009.png'),
                      pygame.image.load('expl_02_0010.png'),
                      pygame.image.load('expl_02_0011.png'),
                      pygame.image.load('expl_02_0012.png'),
                      pygame.image.load('expl_02_0013.png'),
                      pygame.image.load('expl_02_0014.png'),
                      pygame.image.load('expl_02_0015.png'),
                      pygame.image.load('expl_02_0016.png'),
                      pygame.image.load('expl_02_0017.png'),
                      pygame.image.load('expl_02_0018.png'),
                      pygame.image.load('expl_02_0019.png'),
                      pygame.image.load('expl_02_0020.png'),
                      pygame.image.load('expl_02_0021.png'),
                      pygame.image.load('expl_02_0022.png'),
                      pygame.image.load('expl_02_0023.png'), ]

        self.blws = [pygame.image.load('expl_01_0000.png'),
                      pygame.image.load('expl_01_0001.png'),
                      pygame.image.load('expl_01_0002.png'),
                      pygame.image.load('expl_01_0003.png'),
                      pygame.image.load('expl_01_0004.png'),
                      pygame.image.load('expl_01_0005.png'),
                      pygame.image.load('expl_01_0006.png'),
                      pygame.image.load('expl_01_0007.png'),
                      pygame.image.load('expl_01_0008.png'),
                      pygame.image.load('expl_01_0009.png'),
                      pygame.image.load('expl_01_0010.png'),
                      pygame.image.load('expl_01_0011.png'),
                      pygame.image.load('expl_01_0012.png'),
                      pygame.image.load('expl_01_0013.png'),
                      pygame.image.load('expl_01_0014.png'),
                      pygame.image.load('expl_01_0015.png'),
                      pygame.image.load('expl_01_0016.png'),
                      pygame.image.load('expl_01_0017.png'),
                      pygame.image.load('expl_01_0018.png'),
                      pygame.image.load('expl_01_0019.png'),
                      pygame.image.load('expl_01_0020.png'),
                      pygame.image.load('expl_01_0021.png'),
                      pygame.image.load('expl_01_0022.png'),
                      pygame.image.load('expl_01_0023.png'), ]

        self.sheet313 = Sheet(mc2)
        self.player_blows = [self.sheet313.get_image(0,0,40,40),
                                self.sheet313.get_image(40,0,40,40),
                                self.sheet313.get_image(80,0,40,40),
                                self.sheet313.get_image(120,0,40,40),
                                self.sheet313.get_image(160,0,40,40)
                              ]

        self.red1 = pygame.image.load(SHIP2_FRONT).convert()

        self.red2 = pygame.image.load('redfighter0005.png').convert()

        self.red3 = pygame.image.load(SHIP2_LEFT).convert()

        self.red4 = pygame.image.load(SHIP2_RIGHT).convert()

        self.helppic = pygame.image.load(HELPER1).convert()
        self.helppic.set_colorkey((0, 0, 0))
        self.helppic = pygame.transform.flip(self.helppic, False, True)
        self.helppic = pygame.transform.scale(self.helppic, (30, 30))

        self.sheet_b1 = Sheet(BOSS1)

        self.boss1pic = self.sheetb1.get_image(0, 0, 31, 31).convert()

        self.boss1pic = pygame.transform.flip(self.boss1pic, False, True)
        self.boss1pic.set_colorkey((0, 0, 0))
        self.b1faces = [self.sheetb1.get_image(4, 0, 31, 31),
                      self.sheetb1.get_image(36, 0, 31, 31),
                      self.sheetb1.get_image(68, 0, 31, 31),
                      self.sheetb1.get_image(100, 0, 31, 31)]
        for i in self.b1faces:
            i.convert()
            i.set_colorkey(black)

        self.strip = 'portal_strip4.png'
        self.strip2 = 'portal_strip4a.png'
        self.sheetwww = Sheet(self.strip)
        self.sheet2www = Sheet(self.strip2)

        self.bozz = [pygame.image.load('expl_01_0000.png'),
                      pygame.image.load('expl_01_0001.png'),
                      pygame.image.load('expl_01_0002.png'),
                      pygame.image.load('expl_01_0003.png'),
                      pygame.image.load('expl_01_0004.png'),
                      pygame.image.load('expl_01_0005.png'),
                      pygame.image.load('expl_01_0006.png'),
                      pygame.image.load('expl_01_0007.png'),
                      pygame.image.load('expl_01_0008.png'),
                      pygame.image.load('expl_01_0009.png'),
                      pygame.image.load('expl_01_0010.png'),
                      pygame.image.load('expl_01_0011.png'),
                      pygame.image.load('expl_01_0012.png'),
                      pygame.image.load('expl_01_0013.png'),
                      pygame.image.load('expl_01_0014.png'),
                      pygame.image.load('expl_01_0015.png'),
                      pygame.image.load('expl_01_0016.png'),
                      pygame.image.load('expl_01_0017.png'),
                      pygame.image.load('expl_01_0018.png'),
                      pygame.image.load('expl_01_0019.png'),
                      pygame.image.load('expl_01_0020.png'),
                      pygame.image.load('expl_01_0021.png'),
                      pygame.image.load('expl_01_0022.png'),
                      pygame.image.load('expl_01_0023.png'), ]

        self.sheetbub = Sheet('zaps.png')

        self.bubble = [self.sheetbub.get_image(11, 160, 4, 4),
                   self.sheetbub.get_image(18, 159, 6, 6),
                   self.sheetbub.get_image(26, 158, 8, 8),
                   self.sheetbub.get_image(37, 158, 7, 7),
                   self.sheetbub.get_image(46, 157, 9, 9),
                   self.sheetbub.get_image(57, 156, 10, 10),
                   self.sheetbub.get_image(67, 155, 13, 13),
                   self.sheetbub.get_image(82, 154, 12, 12),
                   self.sheetbub.get_image(96, 153, 13, 13),
                   self.sheetbub.get_image(111, 152, 14, 14),
                   self.sheetbub.get_image(127, 151, 15, 15),
                   self.sheetbub.get_image(127, 151, 15, 15),
                   self.sheetbub.get_image(127, 151, 15, 15),
                   self.sheetbub.get_image(127, 151, 15, 15),
                   self.sheetbub.get_image(127, 151, 15, 15),
                   self.sheetbub.get_image(127, 151, 15, 15)]
        for i in self.bubble:
            i.convert()
        self.siders = [pygame.image.load(SIDER1),
                       pygame.image.load(SIDER2),
                        pygame.image.load(SIDER3),
                         pygame.image.load(SIDER4),
                          pygame.image.load(SIDER5),
                           pygame.image.load(SIDER6)]
        for i in self.siders:
            i.convert()







g = Game()
g.show_start_screen()
while g.running:
    g.new()
pygame.quit()
    
        

    
        
        
