import pygame
import random
from spacesets import *
from bullets import *
from sheet import *
from objects import *




class Player(pygame.sprite.Sprite):

    def __init__(self,game):
        pygame.sprite.Sprite.__init__(self)

        self.game = game
        self.sound = playsound(self.game)
        self.sheet = Sheet(mc2)
        self.image = pygame.image.load(SHIP1_FRONT).convert()
            
        self.image.set_colorkey(black)
        
        self.rect = self.image.get_rect()
        self.rect.centerx = wth / 2
        self.rect.bottom = hgt - 10
        self.speedx = 0
        self.speedy = 0
        self.timer = 0
        self.up = 0
        self.state = 0
        self.current_frame = 0
        self.last_update = 0
        self.last_update2 = 0
        self.load()
        self.alive = True
        self.gh = 0
        if self.game.rank == 0:
            self.hp = 1
        if self.game.rank >= 1:
            self.hp = 2
        self.game.damage = 0
        self.game.max_sht_wn1 = pygame.sprite.Group()
        self.can_shoot = True
        self.run1 = True
        self.load()


    def helper(self):
        h = extra(self.rect.centerx + 20,self.rect.bottom + 20)
        all_sprites.add(h)



    def load(self):
        self.blows = self.game.player_blows
        for i in self.blows:
            i.set_colorkey(black)
            i.convert()

        self.frames6 = self.game.Lightbullet

        self.blow = self.game.boss_blows
        for i in self.blows:
            i.set_colorkey(black)
        self.blws = self.game.blws
        for i in self.blows:
            i.set_colorkey(black)
    def update(self):
        

        
        self.speedx = 0
        self.speedy = 0
        keystate = pygame.key.get_pressed()
        if self.speedx == 0 and self.alive == True:
            self.image = pygame.image.load(SHIP1_FRONT)
            self.image.set_colorkey((0,0,0))
        if keystate[pygame.K_UP]:
            self.speedy = -6
        if keystate[pygame.K_LEFT] and self.alive == True:
            self.image = pygame.image.load(SHIP1_LEFT)
            self.image.set_colorkey((0,0,0))
            self.speedx = -6
        if keystate[pygame.K_RIGHT] and self.alive -- True:
            self.image = pygame.image.load(SHIP1_RIGHT)
            self.image.set_colorkey((0,0,0))
            self.speedx = 6
        if keystate[pygame.K_DOWN] and self.alive == True:
            self.speedy = 6


        self.rect.x += self.speedx
        self.rect.y += self.speedy
        if self.rect.right > wth - 10:
            self.rect.right = wth - 10
        if self.rect.left < 10:
            self.rect.left = 10
        if self.rect.bottom >= hgt:
            self.rect.bottom = hgt
        self.timer += self.up
        self.death = pygame.sprite.spritecollide(self,self.game.mobs,True,pygame.sprite.collide_mask)
        self.death2 = pygame.sprite.spritecollide(self,self.game.bullets2, True,pygame.sprite.collide_mask)
        self.death3 = pygame.sprite.spritecollide(self,self.game.siderbulls,True,pygame.sprite.collide_mask)
        if self.death or self.death2 or self.death3:
            if self.game.shielded:
                self.s.kill()
                self.game.sheilded = False
                self.run1 = False
            self.hp -= 1
        if self.hp <= 0:
            self.alive = False
        if not self.alive:
            self.sound.death()
            now = pygame.time.get_ticks()
            no = pygame.time.get_ticks()
            if now - self.last_update > 100:
                self.last_update = now
                self.gh +=1
                self.current_frame = (self.current_frame + 1)% len(self.blows)
                self.image = self.blows[self.current_frame]
            if self.gh == 6:
                self.kill()
        self.mask = pygame.mask.from_surface(self.image)
        self.has_shield()
           
            
            
    def shoot(self):


        if self.game.wepon == 1:
            if len(self.game.max_sht_wn1) > 2:
                self.can_shoot = False
            else:
                self.can_shoot = True
            if self.can_shoot:
                self.game.damage = 2
                bullet = Bulletu1(self.rect.centerx,self.rect.top)
                self.game.gam.add(bullet)
                self.game.bullets.add(bullet)
                self.game.max_sht_wn1.add(bullet)
        if self.game.wepon == 2:
            if len(self.game.max_sht_wn1) > 10:
                self.can_shoot = False
            else:
                self.can_shoot = True
            if self.can_shoot:
                self.game.damage = 1
                for i in range(3):
                    bullet = Bulletu2(self.rect.centerx, self.rect.top)
                    self.game.gam.add(bullet)
                    self.game.bullets.add(bullet)
                    self.game.max_sht_wn1.add(bullet)
        if self.game.wepon == 3:
            self.game.damage = random.choice([1,2,3])
            bullet = Bullet2_1(self.rect.centerx, self.rect.top,self.game)
            self.game.gam.add(bullet)
            self.game.bullets.add(bullet)
        if self.game.wepon == 0:
            self.game.damage = 1
            self.lighting = lighting(self,self.rect.centerx, self.rect.top,self.game)
            self.game.gam.add(self.lighting)
            self.game.bullets.add(self.lighting)
            self.lighting.animate()



    def has_shield(self):
        if self.game.shielded == True and self.run1:
            self.s = sheild(self.game)
            self.game.gam.add(self.s)
            self.game.frontr.add(self.s)
            self.game.frontr.move_to_front(self.s)
            self.hp += 1
            self.run1 = False
            print('shielded')

class Player2(pygame.sprite.Sprite):
    def __init__(self, game):
        pygame.sprite.Sprite.__init__(self)
        #pygame.sprite.LayeredUpdates.move_to_front()
        self.game = game
        self.sheet = Sheet(mc2)
        self.sound = playsound(self.game)
        self.image = self.game.red1

        self.image.set_colorkey(black)

        self.rect = self.image.get_rect()
        self.rect.centerx = wth / 2
        self.rect.bottom = hgt - 10
        self.speedx = 0
        self.speedy = 0
        self.timer = 0
        self.up = 0
        self.state = 0
        self.current_frame = 0
        self.last_update = 0
        self.last_update2 = 0
        self.load()
        self.alive = True
        self.gh = 0
        if self.game.rank == 0:
            self.hp = 1
        if self.game.rank >= 1:
            self.hp = 2
        self.game.damage = 0
        self.game.max_sht_wn1 = pygame.sprite.Group()
        self.can_shoot = True
        self.load()
        self.run1 = True
    def helper(self):
        h = extra(self.rect.centerx + 20, self.rect.bottom + 20)
        all_sprites.add(h)

    def helper2(self):
        h2 = extra(self.rect.centerx - 20, self.rect.bottom - 20)
        all_sprites.add(h2)

    def load(self):
        self.blows = self.game.player_blows

        for i in self.blows:
            i.set_colorkey(black)
            i.convert()
        self.frames6 = self.game.Lightbullet
        self.blow = self.game.boss_blows
        for i in self.blows:
            i.set_colorkey(black)
        self.blws = self.game.blws
        for i in self.blows:
            i.set_colorkey(black)
    def update(self):
        self.speedx = 0
        self.speedy = 0


        self.has_shield()

        keystate = pygame.key.get_pressed()
        if self.speedx == 0 and self.alive == True:
            self.image = self.game.red2
            self.image.set_colorkey(black)
        if keystate[pygame.K_UP]:
            self.speedy = -10
        if keystate[pygame.K_LEFT] and self.alive == True:
            self.image = self.game.red3
            self.image.set_colorkey(black)
            self.speedx = -10
        if keystate[pygame.K_RIGHT] and self.alive - - True:
            self.image = self.game.red4
            self.image.set_colorkey(black)
            self.speedx = 10
        if keystate[pygame.K_DOWN] and self.alive == True:
            self.speedy = 10

        self.rect.x += self.speedx
        self.rect.y += self.speedy
        if self.rect.right > wth - 10:
            self.rect.right = wth - 10
        if self.rect.left < 10:
            self.rect.left = 10
        if self.rect.bottom >= hgt:
            self.rect.bottom = hgt
        self.timer += self.up

        self.death = pygame.sprite.spritecollide(self, self.game.mobs, True,pygame.sprite.collide_mask)
        self.death2 = pygame.sprite.spritecollide(self, self.game.bullets2, True,pygame.sprite.collide_mask)
        self.death3 = pygame.sprite.spritecollide(self, self.game.siderbulls, True, pygame.sprite.collide_mask)
        if self.death or self.death2 or self.death3:
            if self.game.shielded:
                self.s.kill()
                self.game.sheilded = False
                self.run1 = False
        if self.hp <= 0:
            self.alive = False
        if not self.alive:
            now = pygame.time.get_ticks()
            no = pygame.time.get_ticks()
            if now - self.last_update > 100:
                self.last_update = now
                self.gh += 1

                self.current_frame = (self.current_frame + 1) % len(self.blows)
                self.image = self.blows[self.current_frame]
                self.sound.death()
            if self.gh == 6:
                self.kill()
        self.mask = pygame.mask.from_surface(self.image)
    def shoot(self):


        if self.game.wepon == 1:
            if len(self.game.max_sht_wn1) > 2:
                self.can_shoot = False
            else:
                self.can_shoot = True
            if self.can_shoot:
                self.game.damage = 2
                bullet = Bulletu1(self.rect.centerx, self.rect.top)
                self.game.gam.add(bullet)
                self.game.bullets.add(bullet)
                self.game.max_sht_wn1.add(bullet)
        if self.game.wepon == 2:
            if len(self.game.max_sht_wn1) > 10:
                self.can_shoot = False
            else:
                self.can_shoot = True
            if self.can_shoot:
                self.game.damage = 1
                for i in range(3):
                    bullet = Bulletu2(self.rect.centerx, self.rect.top)
                    self.game.gam.add(bullet)
                    self.game.bullets.add(bullet)
                    self.game.max_sht_wn1.add(bullet)
        if self.game.wepon == 3:
            self.game.damage = random.choice([1,2,3])
            bullet = Bullet2_1(self.rect.centerx, self.rect.top,self.game)
            self.game.gam.add(bullet)
            self.game.bullets.add(bullet)
        if self.game.wepon == 0:
            self.game.damage = 1
            self.lighting = lighting(self,self.rect.centerx, self.rect.top)
            self.game.gam.add(self.lighting)
            self.game.bullets.add(self.lighting)
            self.lighting.animate()
    def has_shield(self):
        if self.game.shielded == True and self.run1:
            self.s = sheild(self.game)
            self.game.gam.add(self.s)
            self.game.frontr.add(self.s)
            self.game.frontr.move_to_front(self.s)
            self.hp += 1
            self.run1 = False


class helper(pygame.sprite.Sprite):
    def __init__(self,game):
        self.game = game
        self.game.helper_alive = False
        pygame.sprite.Sprite.__init__(self)
        self.image = self.game.helppic

        
        self.rect = self.image.get_rect()
        self.rect.x = self.game.p.rect.x - 40
        self.rect.y = self.game.p.rect.y
        self.c = 500
 

    def update(self):
        self.rect.x = self.game.p.rect.x - 40
        self.rect.y = self.game.p.rect.y
        self.game.helper_alive = True
        self.count()
        
        

    
    def shoot(self):
        bullet = Bullet(self.rect.centerx ,self.rect.bottom)
        self.game.gam.add(bullet)
        self.game.bullets.add(bullet)
    def count(self):
        self.c -= 1

        if self.c <= 0:
            self.game.helper_alive = False
            self.kill()





class Boss2(pygame.sprite.Sprite):
    def __init__(self, game):
        pygame.sprite.Sprite.__init__(self)
        self.game = game


        self.image = self.game.boss1pic

        self.rect = self.image.get_rect()
        self.rect.x = wth / 2
        self.rect.y = - 100
        self.hp = 10
        self.game.boss1_hp = 10
        self.l = False
        self.r = False
        self.h = False
        self.s = True
        self.alive = True
        self.alive5 = True
        self.mix = random.randrange(-2, 2)
        self.current_frame = 0
        self.last_update = 0
        self.last_update1 = 0
        self.current_frame1 = 0

        self.frame = 0
        self.load()

    def update(self):
        if self.alive:
            self.face()
        self.shoot()

        if self.s:
            self.rect.x += self.mix
            self.rect.y += 1
        if self.l:
            self.rect.x += 1
            self.rect.y += 1
        if self.r:
            self.rect.x -= 1
            self.rect.y += 1
        if self.h:
            self.rect.x += self.mix
            self.rect.y -= 2

        if self.rect.x >= wth - 30:
            self.mix = random.randrange(-2, 2)
            self.rect.x = wth - 30
            self.s = False
            self.r = True
            self.l = False
            self.h = False
        if self.rect.x < 0:
            self.mix = random.randrange(-2, 2)
            self.rect.x = 0
            self.s = False
            self.r = False
            self.l = True
            self.h = False
        if self.rect.y > hgt - 200:
            self.mix = random.randrange(-2, 2)
            self.s = False
            self.r = False
            self.l = False
            self.h = True
        if self.rect.y < 10:
            self.s = True
            self.r = False
            self.l = False
            self.h = False
        if self.rect.x == wth / 2:
            self.mix = random.randrange(-2, 2)
        self.game.death = pygame.sprite.spritecollide(self, self.game.bullets, True)
        if self.game.death:
            self.game.score += 10
            self.game.coin_count += 1
            if self.game.level != 5:
                self.game.boss1_hp -= self.game.damage
            else:
                self.hp -= self.game.damage
        if self.game.boss1_hp <= 0 and self.game.level != 5:
            self.alive = False
            if not self.alive:
                self.animate()
        if self.hp <= 0:
            self.alive = False
            self.animate()

    def load(self):

        self.blows = self.game.bozz


    def shoot(self):
        now = pygame.time.get_ticks()
        if now - self.frame > random.choice([5000, 10000, 15000, 20000, 25000, 30000]):
            self.frame = now

            bb = Bossbulletb(self.rect.centerx, self.rect.midbottom)



            if self.game.p.rect.x < self.game.b.rect.x - 30 and self.game.p.rect.right > self.game.b.rect.left - 20:

                bb = Bossbulletb(self.rect.centerx, self.rect.midbottom)
                bb.speedx = -5
                self.game.gam.add(bb)
                self.game.mobs.add(bb)
            elif self.game.p.rect.x > self.game.b.rect.x + 30 and self.game.p.rect.x < self.game.b.rect.x + 200:
                bb = Bossbulletb(self.rect.centerx, self.rect.midbottom)
                bb.speedx = 5
                self.game.gam.add(bb)
                self.game.mobs.add(bb)
            else:
                bb = Bossbulletb(self.rect.centerx, self.rect.midbottom)
                bb.speedx = 0
                self.game.gam.add(bb)
                self.game.mobs.add(bb)

    def animate(self):
        self.s = False
        self.r = False
        self.l = False
        self.h = False

        now = pygame.time.get_ticks()
        if now - self.last_update > 100:
            self.last_update = now
            self.current_frame = (self.current_frame + 1) % len(self.blows)
            self.image = self.blows[self.current_frame]
        if self.current_frame >= 23:
            self.game.score += 100
            self.game.coin_count += 10
            self.kill()

    def face(self):
        now = pygame.time.get_ticks()
        if now - self.last_update1 > 100:
            self.last_update = now
            self.current_frame1 = (self.current_frame1 + 1) % len(self.game.b1faces)
            self.image = self.game.b1faces[self.current_frame1]
            self.image = pygame.transform.flip(self.image, False, True)
class Bosslvl3(pygame.sprite.Sprite):
    def __init__(self, game):
        pygame.sprite.Sprite.__init__(self)
        self.game = game
        self.sheet = Sheet(BOSSUFO)

        self.image = self.sheet.get_image(0, 0, 31, 31).convert()
        self.image = pygame.transform.flip(self.image, False, True)
        self.image.set_colorkey(white)
        self.rect = self.image.get_rect()
        self.rect.x = wth / 2
        self.rect.y = - 100

        self.l = False
        self.r = False
        self.h = False
        self.s = True
        self.alive = True
        self.mix = random.randrange(-2, 2)
        self.current_frame = 0
        self.last_update = 0
        self.last_update1 = 0
        self.current_frame1 = 0
        self.boss3_hp = 10
        self.hp = 20
        self.frame = 0
        self.load()

    def update(self):
        if self.alive:
            self.face()
        self.shoot()

        if self.s:
            self.rect.x += self.mix
            self.rect.y += 1
        if self.l:
            self.rect.x += 1
            self.rect.y += 1
        if self.r:
            self.rect.x -= 1
            self.rect.y += 1
        if self.h:
            self.rect.x += self.mix
            self.rect.y -= 2

        if self.rect.x >= wth - 30:
            self.mix = random.randrange(-2, 2)
            self.rect.x = wth - 30
            self.s = False
            self.r = True
            self.l = False
            self.h = False
        if self.rect.x < 0:
            self.mix = random.randrange(-2, 2)
            self.rect.x = 0
            self.s = False
            self.r = False
            self.l = True
            self.h = False
        if self.rect.y > hgt - 200:
            self.mix = random.randrange(-2, 2)
            self.s = False
            self.r = False
            self.l = False
            self.h = True
        if self.rect.y < 10:
            self.s = True
            self.r = False
            self.l = False
            self.h = False
        if self.rect.x == wth / 2:
            self.mix = random.randrange(-2, 2)
        self.death = pygame.sprite.spritecollide(self, self.game.bullets, True)
        if self.death:

            self.game.score += 10
            self.game.coin_count += 1
            self.boss3_hp -= self.game.damage

        if self.boss3_hp <= 0:
            self.alive = False
        if not self.alive:
            self.animate()


    def load(self):


        self.faces = [self.sheet.get_image(4, 0, 25, 31),
                      self.sheet.get_image(36, 0, 25, 31),
                      self.sheet.get_image(68, 0, 25, 31),
                      self.sheet.get_image(100, 0, 25, 31)]
        for i in self.faces:
            i.set_colorkey(white)
            i.convert()


    def shoot(self):

        now = pygame.time.get_ticks()
        if now - self.frame > random.choice([5000, 10000, 15000, 20000, 25000, 30000]):
            self.frame = now
            self.flip = random.choice([0, 1])
            if self.flip == 0:

                bb = Bossbullet(self.rect.centerx, self.rect.midbottom)

                if self.game.p.rect.x < self.game.b.rect.x - 30 and self.game.p.rect.right > self.game.b.rect.left - 20:

                    bb = Bossbullet(self.rect.centerx, self.rect.midbottom)
                    bb.speedx = -5
                    self.game.gam.add(bb)
                    self.game.bullets2.add(bb)
                elif self.game.p.rect.x > self.game.b.rect.x + 30 and self.game.p.rect.x < self.game.b.rect.x + 200:
                    bb = Bossbullet(self.rect.centerx, self.rect.midbottom)
                    bb.speedx = 5
                    self.game.gam.add(bb)
                    self.game.bullets2.add(bb)
                else:
                    bb = Bossbullet(self.rect.centerx, self.rect.midbottom)
                    bb.speedx = 0
                    self.game.gam.add(bb)
                    self.game.bullets2.add(bb)
            else:
                bb = Bossbullet_down(self.rect.centerx, self.rect.midbottom)
                bb2 = Bossbullet_left(self.rect.centerx, self.rect.midbottom)
                bb3 = Bossbullet_right(self.rect.centerx, self.rect.midbottom)
                self.game.gam.add(bb)
                self.game.bullets2.add(bb)
                self.game.gam.add(bb2)
                self.game.bullets2.add(bb2)
                self.game.gam.add(bb3)
                self.game.bullets2.add(bb3)

    def animate(self):
        self.s = False
        self.r = False
        self.l = False
        self.h = False

        now = pygame.time.get_ticks()
        if now - self.last_update > 100:
            self.last_update = now
            self.current_frame = (self.current_frame + 1) % len(self.game.boss_blows)
            self.image = self.game.boss_blows[self.current_frame]
        if self.current_frame >= 23:
            self.game.score += 100
            self.game.coin_count += 10

            self.game.boss3_death_count += 1
            self.kill()

    def face(self):
        now = pygame.time.get_ticks()
        if now - self.last_update1 > 100:
            self.last_update = now
            self.current_frame1 = (self.current_frame1 + 1) % len(self.faces)
            self.image = self.faces[self.current_frame1]
            self.image = pygame.transform.flip(self.image, False, True)

class Boss3(pygame.sprite.Sprite):
    def __init__(self, game):
        pygame.sprite.Sprite.__init__(self)
        self.game = game
        self.sheet = Sheet(BOSSDOVE)

        self.image = self.sheet.get_image(0, 0, 31, 31).convert()
        self.image = pygame.transform.flip(self.image, False, True)
        self.image.set_colorkey((0, 0, 0))
        self.rect = self.image.get_rect()
        self.rect.x = wth / 2
        self.rect.y = - 100
        self.game.boss2_hp = 20
        self.l = False
        self.r = False
        self.h = False
        self.s = True
        self.alive = True
        self.mix = random.randrange(-2, 2)
        self.current_frame = 0
        self.last_update = 0
        self.last_update1 = 0
        self.current_frame1 = 0

        self.frame = 0
        self.load()
        self.hp = 15

    def update(self):
        if self.alive:
            self.face()
        self.shoot()
        if self.s:
            self.rect.x += self.mix
            self.rect.y += 2
        if self.l:
            self.rect.x += 1
            self.rect.y += 2
        if self.r:
            self.rect.x -= 1
            self.rect.y += 2
        if self.h:
            self.rect.x += self.mix
            self.rect.y -= 3

        if self.rect.x >= wth - 30:
            self.mix = random.randrange(-1, 1)
            self.rect.x = wth - 30
            self.s = False
            self.r = True
            self.l = False
            self.h = False
        if self.rect.x < 0:
            self.mix = random.randrange(-2, 2)
            self.rect.x = 0
            self.s = False
            self.r = False
            self.l = True
            self.h = False
        if self.rect.y > hgt - 450:
            self.mix = random.randrange(-3, 3)
            self.s = False
            self.r = False
            self.l = False
            self.h = True
        if self.rect.y < 10:
            self.s = True
            self.r = False
            self.l = False
            self.h = False
        if self.rect.x == wth / 2:
            self.mix = random.randrange(-4, 4)
        self.game.death = pygame.sprite.spritecollide(self, self.game.bullets, True)
        if self.game.death:
            if self.game.level != 5:
                self.game.score += 10
                self.game.coin_count += 1
                self.game.boss2_hp -= self.game.damage
            else:
                self.game.score += 5
                self.game.coin_count += 1
                self.hp -= self.game.damage
        if self.game.boss2_hp <= 0:
            self.alive = False
        if self.hp <= 0:
            self.alive = False
        if not self.alive:
            self.animate()

    def load(self):


        self.faces = [self.sheet.get_image(4, 0, 31, 31),
                      self.sheet.get_image(36, 0, 31, 31),
                      self.sheet.get_image(68, 0, 31, 31),
                      self.sheet.get_image(100, 0, 31, 31)]
        for i in self.faces:
            i.set_colorkey(black)
            i.convert()


    def shoot(self):
        now = pygame.time.get_ticks()
        if now - self.frame > random.choice([5000, 10000, 15000, 20000, 25000, 30000]):
            self.frame = now
            choice = random.choice([1,2])
            if choice == 1:
                bb = Bossbullet_down(self.rect.centerx, self.rect.midbottom)
                bb2 = Bossbullet_left(self.rect.centerx, self.rect.midbottom)
                bb3 = Bossbullet_right(self.rect.centerx, self.rect.midbottom)
                self.game.gam.add(bb)
                self.game.bullets2.add(bb)
                self.game.gam.add(bb2)
                self.game.bullets2.add(bb2)
                self.game.gam.add(bb3)
                self.game.bullets2.add(bb3)
            else:
                bs = sider(self.game, self.rect.centerx, self.rect.midbottom)
                self.game.gam.add(bs)
                self.game.siderbulls.add(bs)




    def animate(self):
        self.s = False
        self.r = False
        self.l = False
        self.h = False
        now = pygame.time.get_ticks()
        if now - self.last_update > 100:
            self.last_update = now
            self.current_frame = (self.current_frame + 1) % len(self.game.boss_blows)
            self.image = self.game.boss_blows[self.current_frame]
        if self.current_frame >= 23:
            self.game.score += 100
            self.game.coin_count += 10
            if self.game.level == 5:
                self.kill()

    def face(self):
        now = pygame.time.get_ticks()
        if now - self.last_update1 > 100:
            self.last_update = now
            self.current_frame1 = (self.current_frame1 + 1) % len(self.faces)
            self.image = self.faces[self.current_frame1]
            self.image = pygame.transform.flip(self.image, False, True)


class Boss4(pygame.sprite.Sprite):
    def __init__(self, game):
        pygame.sprite.Sprite.__init__(self)
        self.game = game
        self.image = random.choice([pygame.image.load(BOSSG1).convert(),
                                    pygame.image.load(BOSSG2).convert(),
                                    pygame.image.load(BOSSG3).convert(),
                                    pygame.image.load(BOSSG4).convert()])
        self.image = pygame.transform.flip(self.image, False, True)

        self.image.set_colorkey(white)
        self.rect = self.image.get_rect()
        self.rect.x = random.randrange(50, wth - 50)
        self.rect.y = random.randrange(-hgt * 2, -hgt)

        self.alive = True
        self.mix = random.randrange(1, 3)
        self.current_frame = 0
        self.last_update = 0
        self.last_update1 = 0
        self.current_frame1 = 0
        self.hp = random.randrange(5,12)
        self.frame = 0


    def update(self):
        self.rect.y += self.mix
        if self.alive:
            self.shoot()

        self.game.death = pygame.sprite.spritecollide(self, self.game.bullets, True,pygame.sprite.collide_mask)
        if self.game.death:
            self.game.score += 10
            self.game.coin_count += 1
            self.hp -= 1
        if self.hp <= 0:
            self.alive = False
            if not self.alive:
                self.animate()
        if self.rect.top > hgt:
            self.rect.x = random.randrange(50, wth - 50)
            self.rect.y = random.choice([-hgt, -hgt * 2,-hgt * 3, - hgt * 4, -hgt * 5])
        self.mask = pygame.mask.from_surface(self.image)
        if self.game.level4_done == True:
            self.alive = False









    def shoot(self):
        now = pygame.time.get_ticks()
        if now - self.frame > random.choice([5000, 10000, 15000, 20000, 25000, 30000]):
            self.frame = now

            bb = Bossbullet(self.rect.centerx, self.rect.midbottom)

            if self.game.p.rect.x < self.game.b.rect.x - 30 and self.game.p.rect.right > self.game.b.rect.left - 20:

                bb = Bossbullet(self.rect.centerx, self.rect.midbottom)
                bb.speedx = -5
                self.game.gam.add(bb)
                self.game.bullets2.add(bb)
                self.game.frontr.add(bb)
                self.game.frontr.move_to_front(bb)
            elif self.game.p.rect.x > self.game.b.rect.x + 30 and self.game.p.rect.x < self.game.b.rect.x + 200:
                bb = Bossbullet(self.rect.centerx, self.rect.midbottom)
                bb.speedx = 5
                self.game.gam.add(bb)
                self.game.bullets2.add(bb)
                self.game.frontr.add(bb)
                self.game.frontr.move_to_front(bb)
            else:
                bb = Bossbullet(self.rect.centerx, self.rect.midbottom)
                bb.speedx = 0
                self.game.gam.add(bb)
                self.game.bullets2.add(bb)
                self.game.frontr.add(bb)
                self.game.frontr.move_to_front(bb)

    def animate(self):

        now = pygame.time.get_ticks()
        if now - self.last_update > 100:
            self.last_update = now
            self.current_frame = (self.current_frame + 1) % len(self.game.blws)
            self.image = self.game.blws[self.current_frame]
            self.image = pygame.transform.scale(self.image,(200,200))
        if self.current_frame >= 22:
            self.game.score += 100
            self.game.coin_count += 10
            self.kill()






class Mob(pygame.sprite.Sprite):
    def __init__(self,game):
        pygame.sprite.Sprite.__init__(self)
        self.game = game
        self.sound = playsound(self.game)
        self.image = pygame.image.load(MOB1).convert()
        self.image.set_colorkey((0,0,0))
        
        self.rect = self.image.get_rect()
        self.rect.x = random.randrange(wth - self.rect.width)
        self.rect.y = random.randrange(-100,-40)
        self.speedy = random.randrange(1,8)
        self.speedx = random.randrange(-3,3)
        self.timer = 0
        self.up = 0
        self.current_frame = 0
        self.last_update = 0

    def update(self):
        rando = random.choice((black,white,grey,yellow))
        self.rect.x += self.speedx
        self.rect.y += self.speedy
        self.timer += self.up
        if self.rect.top > hgt + 10:
            self.rect.x = random.randrange(wth - self.rect.width)
            self.rect.y  = random.randrange(-100,-40)
            self.speedy = random.randrange(1,8)

        self.death = pygame.sprite.spritecollide(self,self.game.bullets,True,pygame.sprite.collide_mask)
        if self.death:
            self.sound.death2()
            self.up = 1
            #print('happend')
        #print(str(self.timer))
        if (self.timer >= 5 and self.timer <=20) or (self.timer >= 30 and self.timer <= 40):
            self.image.fill(rando)
        else:
            self.image = pygame.image.load('img2/items/spaceship.png').convert()
            self.image.set_colorkey(black)
        if self.timer >= 50:

            self.game.score += 10
            self.kill()

        self.mask = pygame.mask.from_surface(self.image)
            
class Mob2(pygame.sprite.Sprite):
    def __init__(self,game):
        pygame.sprite.Sprite.__init__(self)
        self.game = game
        self.sound = playsound(self.game)
        self.image = pygame.image.load(MOB2).convert()
        self.image.set_colorkey((0,0,0))
        self.alive = True
        self.rect = self.image.get_rect()
        self.rect.x = random.randrange(wth - self.rect.width)
        self.rect.y = random.randrange(-250,-40)
        self.speedy = random.randrange(3,10)
        self.speedx = random.randrange(-3,8)
        self.last_update = 0
        self.current_frame = 0

        

    def update(self):
        self.game.m2death = pygame.sprite.spritecollide(self,self.game.bullets,True,pygame.sprite.collide_mask)
        if self.game.m2death:
            self.sound.lilboom()
            self.alive = False
        self.rect.x += self.speedx
        self.rect.y += self.speedy
        if self.rect.top > hgt + 10:
            self.rect.x = random.randrange(wth - self.rect.width)
            self.rect.y  = random.randrange(-100,-40)
            self.speedy = random.randrange(1,8)
        if not self.alive:
            self.ani()
        self.mask = pygame.mask.from_surface(self.image)
    def ani(self):
        self.speedy = 0
        self.speedx = 0
        now = pygame.time.get_ticks()
        if now - self.last_update > 100:
            self.last_update = now
            self.current_frame = (self.current_frame + 1)% len(self.game.boss_blows)
            self.image = self.game.boss_blows[self.current_frame]
        if self.current_frame >= 23:
            self.game.score += 10
            self.kill()
        
class Mob3(pygame.sprite.Sprite):
    def __init__(self,game):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.image.load(MOB3).convert()
        self.image.set_colorkey((0,0,0))
        self.game = game
        self.rect = self.image.get_rect()
        self.rect.x = random.randrange(50,wth)
        self.rect.y = random.randrange(-75,0)
        self.speedy = 1
        self.speedx = 0
        self.l = False
        self.r = False
        self.h = False
        self.s = True
        self.last_update = 0
        self.current_frame = 0
        self.hp = 3
    def update(self):
        self.rect.x += self.speedx
        self.rect.y += self.speedy
        if self.rect.left > 400:
            self.rect.left = 400
            self.s = False
            self.l = False
            self.r = True
        elif self.rect.right < 0:
            self.rect.right = 0
            self.s = False
            self.l = True
            self.r = False
        if self.rect.y >= hgt / 2:
            self.h = True
            self.s = False
        else:
            self.h = False
        
        self.shoot()
        self.movement()
        self.death()
        self.mask = pygame.mask.from_surface(self.image)
    def shoot(self):
        now = pygame.time.get_ticks()
        if now - self.last_update > random.choice([10000,30000]):
            self.last_update = now
            bb = Bullet2(self.rect.centerx,self.rect.top)
            self.game.gam.add(bb)
            self.game.bullets2.add(bb)
    def movement(self):
        if self.s:
            self.speedy = 1
            self.speedx = 0
        if self.r:
            self.speedy = 0
            self.speedx = -1
        if self.l:
            self.speedy = 0
            self.speedx = 1
        if self.h:
            self.speedy = -1
            self.speedx = random.choice([-1,1])
        
    def death(self):
        self.game.m3death = pygame.sprite.spritecollide(self,self.game.bullets,True,pygame.sprite.collide_mask)
        if self.game.m3death:
            self.hp -= self.game.damage
        if self.hp <= 0:
            self.game.score += 30
            self.kill()
            
                
                
        
class Mob4(pygame.sprite.Sprite):
    def __init__(self):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.image.load(MOB4).convert()
        self.image.set_colorkey((0,0,0))
        
        self.rect = self.image.get_rect()
        self.rect.x = random.randrange(50,350)
        self.rect.y = random.randrange(-75,0)
        self.speedy = 2
        self.speedx = 0
        self.hp = 5
        self.hp_take = 1
        
        
    
    def update(self):
        self.rect.x += self.speedx
        self.rect.y += self.speedy
        if self.rect.left > 400:
            self.rect.left = 400
        elif self.rect.right < 0:
            self.rect.right = 0
        if self.rect.top > height + 10:
            self.rect.top = random.randrange(-50,0)
        self.mask = pygame.mask.from_surface(self.image)
            
    def shoot(self):
        bb = Bullet2(self.rect.centerx,self.rect.top)
        all_sprites.add(bb)
        bullets2.add(bb)
    
        
class Boss(pygame.sprite.Sprite):
    def __init__(self):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.image.load('boss1.png').convert()
        
        self.image.set_colorkey((0,0,0))
        
        self.rect = self.image.get_rect()
        self.rect.x = 30
        self.rect.y = 50
        self.speedy = 0
        self.speedx = 0
    def update(self):

        if self.rect.top > height + 10:
            self.rect.top = random.randrange(-50,0)

    def shoot(self):
        bb = Bossbullet(self.rect.centerx,self.rect.top)
        all_sprites.add(bb)
        bullets2.add(bb)

class Alex001(pygame.sprite.Sprite):
    def __init__(self,game):
        pygame.sprite.Sprite.__init__(self)
        self.game = game
        self.image = pygame.image.load(ALEX1).convert()
        self.image.set_colorkey((255,255,255))
        
        self.rect = self.image.get_rect()
        self.rect.x = random.randrange(50,wth - 50)
        self.rect.y = random.randrange(-75,0)
        self.speedy = random.randrange(2,4)
        self.speedx = random.randrange(-1,1)
        self.timer = 0
        self.timer2 = 0
        self.growtimer = 0.5
        self.hp = 5
        self.timo = 0
        self.up = 0
        self.i = True
        
    def update(self):
        rando = random.choice((black,white,grey,yellow))
        self.timo += self.up
        self.timer += self.growtimer
        self.ani()
        if self.timer == 40:
            self.timer = 0
        self.rect.x += self.speedx
        self.rect.y += self.speedy
        if self.rect.x >= wth:
            self.rect.x = wth
        if self.rect.x <= 0:
            self.rect.x = 0
        if self.timer < 20:
            self.i = True
            self.rect.x += 2
        if self.timer > 20:
            self.i = False
            self.rect.x -= 2
        if self.rect.top > hgt + 10:
            self.rect.top = random.randrange(-50,0)
        if self.timer ==0.5:
            self.shoot()

        self.game.oodeath = pygame.sprite.spritecollide(self, self.game.bullets, True,pygame.sprite.collide_mask)
        if self.game.oodeath:
            self.hp -= self.game.damage
        if self.hp <= 0:
            self.up = 1
            #print('happend')
        #print(str(self.timer))
        if (self.timo >= 5 and self.timo <=20) or (self.timo >= 40 and self.timo <= 60) or (self.timo > 80):
            self.image.fill(rando)
        else:
            if not self.i:
                self.image = pygame.image.load('Alex001.png').convert()
                self.image.set_colorkey(white)
            else:
                self.image = pygame.transform.flip(self.image,True,False)
                self.image.set_colorkey(white)
        if self.timo >= 100:
            self.game.score += 20
            self.kill()
        self.mask = pygame.mask.from_surface(self.image)
        
    def shoot(self):
        bb3 = Bullet3(self.rect.centerx,self.rect.top)
        self.game.gam.add(bb3)
        self.game.bullets2.add(bb3)
    def ani(self):
        if self.i:
            self.image = pygame.image.load('Alex001.png').convert()
        else:
            self.image = pygame.transform.flip(self.image,True,False)

class Meteor(pygame.sprite.Sprite):
    def __init__(self,game):
        pygame.sprite.Sprite.__init__(self)
        self.game = game
        
        self.sheet = Sheet(spritesheet)
        self.sheet2 = Sheet(ass)
        self.image = random.choice([self.sheet2.get_image6(0, 0, 117, 123),
                                    self.sheet2.get_image6(203, 0, 76, 80)]).convert()

        self.image.set_colorkey(white)
        
        self.rect = self.image.get_rect()
        self.rect.x = random.randrange(wth - self.rect.width)
        self.rect.y = random.randrange(-1000,-40)
        self.speedy = random.randrange(1,8)
        self.speedx = random.randrange(-3,3)
        self.current_frame = 0
        self.last_update = 0
        self.load()
        self.gh = 0
        self.alive = True
        self.hp = 2
    def load(self):
        self.blows = [self.sheet.get_image(0,0,40,40),
                                self.sheet.get_image(40,0,40,40),
                                self.sheet.get_image(80,0,40,40),
                                self.sheet.get_image(120,0,40,40),
                                self.sheet.get_image(160,0,40,40)
                              ]
        for i in self.blows:
            i.set_colorkey(black)
    def update(self):
        
        self.rect.x += self.speedx
        self.rect.y += self.speedy
        if self.rect.top > hgt + 10:
            self.rect.x = random.randrange(wth - self.rect.width)
            self.rect.y  = random.randrange(-100,-40)
            self.speedy = random.randrange(1,8)
        self.death = pygame.sprite.spritecollide(self,self.game.bullets,True,pygame.sprite.collide_mask)
        if self.death:
            self.hp -= self.game.damage
            self.game.score += 2
        if self.hp <= 0:
            self.alive = False
            
            
        if self.alive == False:
            self.speedx = 0
            self.speedy = 0
            now = pygame.time.get_ticks()
            if now - self.last_update > 100:
                self.last_update = now
                self.gh +=1
                self.current_frame = (self.current_frame + 1)% len(self.blows)
                self.image = self.blows[self.current_frame]
            if self.gh == 6:
                
                self.kill()
        self.mask = pygame.mask.from_surface(self.image)

class Meteora(pygame.sprite.Sprite):
    def __init__(self, game):
        pygame.sprite.Sprite.__init__(self)
        self.game = game

        self.sheet = Sheet(spritesheet)
        self.sheet2 = Sheet(ass)
        self.image = self.sheet2.get_image6(0, 0, 117, 123).convert()


        self.image.set_colorkey(white)

        self.rect = self.image.get_rect()
        self.rect.x = random.randrange(wth - self.rect.width)
        self.rect.y = random.randrange(-1000, -40)
        self.speedy = random.randrange(1, 8)
        self.speedx = random.randrange(-3, 3)
        self.current_frame = 0
        self.last_update = 0
        self.load()
        self.gh = 0
        self.alive = True
        self.hp = 2

    def load(self):
        self.blows = [self.sheet.get_image(0, 0, 40, 40),
                      self.sheet.get_image(40, 0, 40, 40),
                      self.sheet.get_image(80, 0, 40, 40),
                      self.sheet.get_image(120, 0, 40, 40),
                      self.sheet.get_image(160, 0, 40, 40)
                      ]
        for i in self.blows:
            i.set_colorkey(black)
            i.convert()

    def update(self):

        self.rect.x += self.speedx
        self.rect.y += self.speedy
        if self.rect.top > hgt + 10:
            self.rect.x = random.randrange(wth - self.rect.width)
            self.rect.y = random.randrange(-100, -40)
            self.speedy = random.randrange(1, 8)
        self.death = pygame.sprite.spritecollide(self, self.game.bullets, True,pygame.sprite.collide_mask)
        if self.death:
            self.hp -= self.game.damage
            self.game.score += 2
        if self.hp <= 0:
            self.alive = False

        if self.alive == False:
            now = pygame.time.get_ticks()
            if now - self.last_update > 100:
                self.last_update = now
                self.gh += 1
                self.current_frame = (self.current_frame + 1) % len(self.blows)
                self.image = self.blows[self.current_frame]
            if self.gh == 2:
                m = Meteor2(self)
                self.game.gam.add(m)
                self.game.mobs.add(m)
            if self.gh == 6:
                m = Meteor2(self)
                self.game.gam.add(m)
                self.game.mobs.add(m)
                self.kill()
        self.mask = pygame.mask.from_surface(self.image)

class Meteor2(pygame.sprite.Sprite):
    def __init__(self, starter):
        pygame.sprite.Sprite.__init__(self)
        self.starter = starter

        self.sheet = Sheet(spritesheet)
        self.sheet2 = Sheet(ass)
        self.image = random.choice([self.sheet2.get_image6(163,81,26,40),
                                    self.sheet2.get_image6(200,80,41,44),
                                    self.sheet2.get_image6(240,160,20,22),
                                    self.sheet2.get_image6(0,125,40,87),
                                    self.sheet2.get_image6(140,132,56,48),
                                    self.sheet2.get_image6(242,81,38,34)])



        self.image.set_colorkey(white)

        self.rect = self.image.get_rect()
        self.rect.x = self.starter.rect.x
        self.rect.y = self.starter.rect.y
        self.speedy = random.randrange(1, 8)
        self.speedx = random.randrange(-3, 3)
        self.current_frame = 0
        self.last_update = 0
        self.load()
        self.gh = 0
        self.alive = True
        self.hp = 2

    def load(self):
        self.blows = [self.sheet.get_image(0, 0, 40, 40),
                      self.sheet.get_image(40, 0, 40, 40),
                      self.sheet.get_image(80, 0, 40, 40),
                      self.sheet.get_image(120, 0, 40, 40),
                      self.sheet.get_image(160, 0, 40, 40)
                      ]
        for i in self.blows:
            i.set_colorkey(black)
            i.convert()

    def update(self):

        self.rect.x += self.speedx
        self.rect.y += self.speedy
        if self.rect.top > hgt + 10:
            self.rect.x = random.randrange(wth - self.rect.width)
            self.rect.y = random.randrange(-100, -40)
            self.speedy = random.randrange(1, 8)
        self.death = pygame.sprite.spritecollide(self, self.starter.game.bullets, True,pygame.sprite.collide_mask)
        if self.death:
            self.hp -= self.starter.game.damage
            self.starter.game.score += 2
        if self.hp <= 0:
            self.alive = False

        if self.alive == False:
            now = pygame.time.get_ticks()
            if now - self.last_update > 100:
                self.last_update = now
                self.gh += 1
                self.current_frame = (self.current_frame + 1) % len(self.blows)
                self.image = self.blows[self.current_frame]
            if self.gh == 6:
                self.kill()
        self.mask = pygame.mask.from_surface(self.image)
        
class help_drop(pygame.sprite.Sprite):
    def __init__(self, game):
        pygame.sprite.Sprite.__init__(self)
        self.game = game
        self.game.dw = pygame.sprite.Group()

        self.star_pill = 50
        self.image = pygame.image.load(POWERUP1)
        self.image = pygame.transform.scale(self.image, (self.star_pill, self.star_pill))
        self.image.set_colorkey(white)

        self.rect = self.image.get_rect()
        self.rect.x = random.randrange(25, wth - 25)
        self.rect.y = random.randrange(-hgt, -10)
        self.speedy = 2
        self.speedx = 0
        self.can_hit = pygame.sprite.Group()
        self.t = tex(self.rect.x, self.rect.x, self.game)
        self.game.gam.add(self.t)
        self.t.image = pygame.transform.scale(self.t.image, (50, 70))
        self.can_hit.add(self.game.p)
        self.go = False
        self.n = 0
        self.s = 0
        self.game.gam.draw(self.image)
        self.hitn = False
        self.starplus = 0
        self.gframe = 0
        self.grow_time = 0
        self.t.draw_text_wit_clr('get me', 40, red)

    def hits(self):
        self.game.gets_help = pygame.sprite.spritecollide(self, self.can_hit, False, pygame.sprite.collide_mask)
        if self.game.gets_help:
            self.game.helper = helper(self.game)
            self.game.gam.add(self.game.helper)
            self.game.player.add(self.game.helper)
            self.go = True

    def update(self):
        self.image = pygame.transform.scale(self.image, (self.star_pill, self.star_pill))
        self.star_pill += self.starplus
        self.t.rect.x = self.rect.x
        self.t.rect.y = self.rect.y
        #self.rand_c = random.choice([white, red, blue, green, purple, pink, hotpink])
        #self.t.draw_text_wit_clr('get me', 40, self.rand_c)
        self.rect.x += self.speedx
        self.rect.y += self.speedy
        if self.rect.top > hgt + 10000:
            self.t.kill()
            self.kill()

        self.hits()
        self.complete()
        self.mask = pygame.mask.from_surface(self.image)

    def complete(self):
        if self.go == True:
            self.image = pygame.image.load('cool_boss2.png')
            self.image = pygame.transform.scale(self.image, (50, 50))
            self.image = pygame.transform.flip(self.image, False, True)
            self.image.set_colorkey(white)
            now = pygame.time.get_ticks()
            if now - self.n > random.choice([10000, 20000, 30000, 40000, 50000]):
                self.n - now
                self.speedx = random.randrange(-10, 10)
                self.speedy = random.randrange(-10, 10)
                self.s += 1
            if self.s == 100:
                self.t.kill()
                self.kill()

    def updown(self):
        self.grow_time += 1
        if self.grow_time >= 9:
            self.grow_time = 1
        if self.grow_time >= 4:
            self.starplus = 1
        else:
            self.starplus = -1

class help_drop2(pygame.sprite.Sprite):
    def __init__(self, game):
        pygame.sprite.Sprite.__init__(self)
        self.game = game
        self.game.dw = pygame.sprite.Group()

        self.star_pill = 50
        self.image = pygame.image.load(POWERUP2)
        self.image = pygame.transform.scale(self.image, (self.star_pill, self.star_pill))
        self.image.set_colorkey(white)

        self.rect = self.image.get_rect()
        self.rect.x = random.randrange(25, wth - 25)
        self.rect.y = random.randrange(-hgt, -10)
        self.speedy = 2
        self.speedx = 0
        self.can_hit = pygame.sprite.Group()
        self.t = tex(self.rect.x, self.rect.x, self.game)
        self.game.gam.add(self.t)
        self.t.image = pygame.transform.scale(self.t.image, (50, 70))
        self.can_hit.add(self.game.p)
        self.go = False
        self.n = 0
        self.s = 0
        self.game.gam.draw(self.image)
        self.hitn = False
        self.starplus = 0
        self.gframe = 0
        self.grow_time = 0
        self.t.draw_text_wit_clr('get me', 40, red)
        self.last_update = 0
        self.current_frame = 0

    def hits(self):
        self.game.gets_help = pygame.sprite.spritecollide(self, self.can_hit, False, pygame.sprite.collide_mask)
        if self.game.gets_help:
            self.game.shielded = True
            self.go = True

    def update(self):
        self.animate()
        self.image = pygame.transform.scale(self.image, (self.star_pill, self.star_pill))
        self.star_pill += self.starplus
        self.t.rect.x = self.rect.x
        self.t.rect.y = self.rect.y

        self.rect.x += self.speedx
        self.rect.y += self.speedy
        if self.rect.top > hgt + 10:
            self.t.kill()
            self.kill()

        self.hits()
        self.complete()
        self.mask = pygame.mask.from_surface(self.image)

    def complete(self):
        if self.go:
            self.image.set_colorkey(white)
            now = pygame.time.get_ticks()
            if now - self.n > random.choice([10000, 20000, 30000, 40000, 50000]):
                self.n - now
                self.speedx = random.randrange(-10, 10)
                self.speedy = random.randrange(-10, 10)
                self.s += 1
            if self.s == 100:
                self.t.kill()
                self.kill()

    def updown(self):
        self.grow_time += 1
        if self.grow_time >= 9:
            self.grow_time = 1
        if self.grow_time >= 4:
            self.starplus = 1
        else:
            self.starplus = -1

    def animate(self):
        now = pygame.time.get_ticks()
        if now - self.last_update > 250:
            self.current_frame = (self.current_frame + 1) % len(self.game.SHEILD)
            self.image = self.game.SHEILD[self.current_frame]
            self.image = pygame.transform.scale(self.image,(160,100))

class sheild(pygame.sprite.Sprite):
    def __init__(self,game):
        pygame.sprite.Sprite.__init__(self)
        self.game = game
        self.image = pygame.image.load('shield2\\00.png')
        self.rect = self.image.get_rect()
        self.rect.x = self.game.p.rect.x
        self.rect.y = self.game.p.rect.y

        self.last_update = 0
        self.current_frame = 0

    def update(self):
        self.animate()
        if self.game.ship == 1:
            self.rect.x = self.game.p.rect.x - 50
            self.rect.y = self.game.p.rect.y - 20
        if self.game.ship == 2:
            self.rect.x = self.game.p.rect.x - 30
            self.rect.y = self.game.p.rect.y - 10

    def animate(self):
        now = pygame.time.get_ticks()
        if now - self.last_update > 250:
            self.current_frame = (self.current_frame + 1) % len(self.game.SHEILD)
            self.image = self.game.SHEILD[self.current_frame]
            self.image = pygame.transform.scale(self.image,(160,100))




